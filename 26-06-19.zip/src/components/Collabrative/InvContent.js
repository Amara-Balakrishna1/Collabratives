import React from "react";
import { Label, Icon, Persona, PersonaSize } from "office-ui-fabric-react";

class InvContent extends React.Component {
  state = {}
  render() {
    return (
      <div className="inv-content">
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Collaborative Name</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">Fresh Produce (Food Saftery)</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Goal</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">
              Collaborate to create AI models that indicates the quality of
              fresh produced in stores and predict recall{" "}
            </Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Industry</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">Food Saftery</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Data Context</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">
              Supply chain data, Quality assesment Data
            </Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Recommended Format</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">CSV</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Sort By(Admin Organization)</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">Microsoft (Cameron Evang)</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Received On</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">Mon at 8:30pm</Label>
          </div>
        </div>
        <div
          className="row orgData"
          onMouseEnter={() => {
            this.setState({
              showAddInfo: true
            });
          }}
          onMouseLeave={() => {
            this.setState({
              showAddInfo: false
            });
          }}
        >
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Collaborating Organization</Label>
          </div>
          <div className="col-xs-6 text-left" style={{ position: "relative" }}>
            <div>
              <Label className="value">3 accepted; 10 invited</Label>
            </div>
            {this.state.showAddInfo ? (
              <div className="addInfo">
                <table
                  style={{ width: "100%", color: "#323130", fontSize: "14px" }}
                >
                  {[{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}].map(
                    (d, i) => (
                      <tr style={{ height: "35px" }}>
                        <td>
                          <Persona
                            size={PersonaSize.size32}
                            primaryText="abc@microsoft.com"
                          />
                        </td>
                        <td>{i < 4 ? "Accepted" : "Pending"}</td>
                      </tr>
                    )
                  )}
                </table>
              </div>
            ) : null}
          </div>
          <div className="col-xs-1">
            <Icon iconName="ChevronDown" className="ms-IconExample" />
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Terms of Use</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">
              Data shared in the collaboratives should not be copied and used
              only for stated goal
            </Label>
          </div>
        </div>
      </div>
    );
  }
}
export default InvContent;
