import React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";

const wrapper = props => (
  <div className={`${props.className || ''} addData-content`}>
    <Icon
      iconName="Cancel"
      className="ms-IconExample cancel"
      onClick={() => props.toggleData(props.name)}
    />
    {props.children}
  </div>
);
export default wrapper;
