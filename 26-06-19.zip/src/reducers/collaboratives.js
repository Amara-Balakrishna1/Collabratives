import {
  GET_COLLAborativeS,
  GET_COLLAborativeDETAILS,
  MANAGE_NOTIFICATION
} from "../actions/collaborativesActions";

import { GET_RESOURCEGROUP } from "../actions/collaborativeInviteAction";

export default function visibilityFilter(state = {}, action) {
  switch (action.type) {
    case GET_COLLAborativeS: {
      const { data = [], industries = [], formats = [] } = action;
      return { ...state, collaboratives: data, industries, formats };
    }
    case GET_RESOURCEGROUP: {
      return { ...state, resourceGroupOptions: action.data };
    }
    case GET_COLLAborativeDETAILS:
      const { roles, statuses, subscriptions } = action;
      return {
        ...state,
        collaborativeDetail: action.data,
        collaborativeTerms: action.terms,
        organizations: action.organizations,
        members: action.members,
        roles,
        subscriptions,
        statuses
      };
    case MANAGE_NOTIFICATION: {
      const { TimeLoader, displayMsg, notification } = action;
      return {
        ...state,
        TimeLoader,
        displayMsg,
        notification
      };
    }
    default:
      return state;
  }
}
