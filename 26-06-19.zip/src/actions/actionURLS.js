const serverURL = "https://collaborativesfunctions.azurewebsites.net/api/";

function getCookie(name) {
  const re = new RegExp(`${name}=([^;]+)`);
  const value = re.exec(document.cookie);
  return value != null ? unescape(value[1]) : null;
}

const userID = getCookie("userId") || "810917c0-9083-4afa-b783-caa9010dc806";
const userURL = `${serverURL}users/${userID}`;
const commInvite = `${serverURL}users/${userID}/collaborations/`


const url = {
  getAllCollaboratives: `${serverURL}users/${userID}/collaborations`,
  getIndustries: `${serverURL}industries`,
  getFormats: `${serverURL}formats`,
  getCollaborativeInfo: `${serverURL}users/${userID}/collaborations/`,
  postCollaboration: `${serverURL}users/${userID}/collaborations`,
  fileUpload: `${serverURL}files`,
  postData: `${serverURL}users/${userID}/collaborations/`,
  //comm  invite 
        // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/inviteorganization`
        // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/invitemember
        // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/join
        // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/organizations get call        
        // inviteorganization:`${serverURL}users/${userId}/collaborations/`terms`,//{collaborationId}/terms get call
  //comm for invite
  userURL,
  commInvite,
  // get dropdowns
  getMemberroles: `${serverURL}memberroles`,
  getMemberStatuses: `${serverURL}memberstatuses`
  // get dropdowns
};

export default url;
