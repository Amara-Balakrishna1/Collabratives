import axios from "axios";
import config from "./config";
import urls from "./actionURLS";

export const GET_COLLAborativeS = "GET_COLLAborativeS";
export const GET_COLLAborativeDETAILS = "GET_COLLAborativeDETAILS";
export const MANAGE_NOTIFICATION = "MANAGE_NOTIFICATION";

export const errorTxt = "ERROR";
export const success = "SUCCESS";

export function onLoader() {
  return {
    notification: "",
    TimeLoader: true,
    displayMsg: "",
    type: MANAGE_NOTIFICATION
  };
}

export function offLoader(notification, displayMsg) {
  return {
    notification,
    TimeLoader: false,
    displayMsg,
    type: MANAGE_NOTIFICATION
  };
}
export function getCollaboratives() {
  const arr = [
    axios.get(`${urls.getAllCollaboratives}`, config),
    axios.get(`${urls.getIndustries}`, config),
    axios.get(`${urls.getFormats}`, config),
    axios.get(`${urls.getMemberroles}`, config)  
  ];
  return dispatch => {
    axios
      .all(arr)
      .then(
        axios.spread((list, industries, formats) => {
          dispatch({
            type: GET_COLLAborativeS,
            data: list.data,
            industries: industries.data,
            formats: formats.data
          });
        })
      )
      .catch();
  };
}

export function getCollaborativeDetail(collaborationId) {
  return dispatch => {
    console.log(`${urls.getCollaborativeInfo}${collaborationId}`);
    const arr = [
      axios.get(`${urls.getCollaborativeInfo}${collaborationId}`, config),
      axios.get(`${urls.commInvite}${collaborationId}/terms`, config),
      axios.get(`${urls.commInvite}${collaborationId}/organizations`, config),
      axios.get(`${urls.commInvite}${collaborationId}/members`, config),      
    axios.get(`${urls.getMemberStatuses}`, config),
    axios.get(`${urls.getMemberroles}`, config)  ,
    axios.get(`${urls.userURL}/subscriptions`, config)  
    ];
    axios
      .all(arr)
      .then(
        axios.spread((result, terms, organizations, members, statuses, roles, subscriptions) => {
          dispatch({
            type: GET_COLLAborativeDETAILS,
            data: result.data,
            terms: terms.data,
            organizations: organizations.data,
            members: members.data,
            roles: roles.data,
            statuses: statuses.data,
            subscriptions: subscriptions.data
          });
        })
      )
      .catch(err => {
        console.log("error");
      });
  };
}

export function createCollaborative(data) {
  return dispatch => {
    // console.log(dispatch, data);
    axios
      .post(`${urls.postCollaboration}`, data, config)
      .then(result => {
        // dispatch({
        //   type: GET_COLLAborativeDETAILS,
        //   data: result.data
        // });
        // console.log(result, data);
        dispatch(getCollaboratives());
      })
      .catch(err => {
        alert(err.response.data.message);
        console.log("error");
      });
  };
}

export function postData(collaborationId, data, component) {
  return dispatch => {
    dispatch(onLoader());
    axios
      .post(`${urls.postData}${collaborationId}/datasets`, data, config)
      .then(result => {
        dispatch(getCollaborativeDetail(collaborationId));
        dispatch(offLoader(success, result.data));
        component.setState({
          showAMember: false,
          showIOrganization: false,
          showAddData: false
        });
      })
      .catch(err => {
        dispatch(offLoader(errorTxt, err.response.data.message));
      });
  };
}
