import React, { Component } from "react";
// import ReactDOM from "react-dom";
import { Icon, IconType } from "office-ui-fabric-react/lib/Icon";
import IconOne from "../images/IconOne.png";
import LoginImg from "../images/Login.png";
import "./Login.scss";
import {
  Label,
  DefaultButton,
  Link,
  PrimaryButton
} from "office-ui-fabric-react";

class Login extends Component {
  render() {
    return (
      <div className="login">
        <div className="half">
          <img className="bgImage" src={LoginImg} />
          <div className="col-xs-6 header">
            <Icon
              // iconName="Waffle"
              iconType={IconType.image}
              className="ms-IconExample"
              styles={{ width: "auto", height: "30px" }}
              imageProps={{
                src: IconOne
              }}
            />
            <Label>Collaborative</Label>
          </div>
          <div className="row text-center"> Microsoft Collaboratives</div>
          <div className="row text-center">
            Collaborate on Data to build powerful AI models together
          </div>
          <div className="row text-center">
            <Link>
              <PrimaryButton> Get Started </PrimaryButton>
            </Link>{" "}
            <Link>
              <DefaultButton>Contact Us</DefaultButton>
            </Link>
          </div>
        </div>
        <div className="half"> sdfa</div>
      </div>
    );
  }
}

export default Login;
