import React from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import {
  /*IPersonaSharedProps,*/ Persona,
  PersonaSize,
  PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
import { Icon, IconType } from "office-ui-fabric-react/lib/Icon";
import { FocusZone } from "office-ui-fabric-react/lib/FocusZone";
import { List } from "office-ui-fabric-react/lib/List";
import { offLoader } from "../actions/collaborativesActions";
import user from "../images/img_avatar.png";
import IconOne from "../images/IconOne.png";
import Spinner from "../images/spinner.gif";

const examplePersona = {
  imageUrl: user
  // imageInitials: 'AR',
  // text: 'Annie Reid',
  // secondaryText: 'Designer',
  // tertiaryText: 'In a meeting',
  // optionalText: 'Available at 4:00pm',
  // showSecondaryText: true
};

class Header extends React.Component {
  myRef = React.createRef();
  state = {
    items: [
      {
        label: "Collaboratives",
        iconName: "collabrative-svg",
        pathName: "/",
        showCount: false
      },
      {
        label: "Invitations",
        iconName: "Mail",
        pathName: "/invitations",
        showCount: false,
        count: 5
      },
      {
        label: "Organizations",
        iconName: "CityNext2",
        pathName: "/",
        showCount: false
      },
      {
        label: "Data",
        iconName: "Database",
        pathName: "/",
        showCount: false
      }
    ],
    sideNav: true
  };
  toogleSidenav = () => {
    this.setState({
      sideNav: !this.state.sideNav
    });
  };
  onRenderCell = (item, index) => {
    console.log(item);
    return (
      <div className={`row ${index ? "" : "active"}`}>
        <div className="col-xs-2">
          <Icon
            iconName={item.iconName || "LocationCircle"}
            className="ms-IconExample"
          />
        </div>
        <div className="col-xs-10">
          <Link to={item.pathName} className="ms-ListGridExample-tile">
            {item.label}
            {item.showCount ? <span>{`(${item.count})`}</span> : null}
          </Link>
        </div>
      </div>
    );
  };
  clearNotification = () => {
    this.props.dispatch(offLoader());
  };
  render() {
    const { props } = this;
    const { items } = this.state;
    const { TimeLoader, notification, displayMsg } = props;
    return (
      <div>
        {TimeLoader ? (
          <div className="overlay">
            <img src={Spinner} alt="spinner" />
          </div>
        ) : null}
        {notification === "SUCCESS" ? (
          <div className="notificationSuccess">
            <p>
              <i
                className="fa fa-check-circle"
                style={{ fontSize: "18px", margin: "0 5px" }}
              />
              {displayMsg}
              <Icon
                iconName="Cancel"
                style={{ fontSize: "18px", margin: "0 5px", cursor: "pointer" }}
                className="ms-IconExample pull-right"
                onClick={e => this.clearNotification(e)}
              />
            </p>
          </div>
        ) : (
          ""
        )}
        {this.props.notification === "ERROR" ? (
          <div className="notificationError">
            <p>
            <Icon
                iconName="Cancel"
                style={{ fontSize: "18px", margin: "0 5px", cursor: "pointer" }}
                className="ms-IconExample pull-right"
                onClick={e => this.clearNotification(e)}
              />
              {displayMsg}
            </p>
          </div>
        ) : (
          ""
        )}
        <div className={`col-xs-12 ${props.className}`}>
          <div className="col-xs-4 title">
            <div className="col-xs-1">
              <Icon
                // iconName="Waffle"
                iconType={IconType.image}
                className="ms-IconExample"
                // styles={{ width: "auto", height: "22px" }}
                imageProps={{
                  src: IconOne
                }}
              />
            </div>
            <div className="col-xs-11">Collaborative</div>
          </div>
          {/* <i class="fa fa-bell" aria-hidden="true"></i> */}
          <div className="col-xs-2 pull-right notifications">
            <div className="col-xs-2">
              <Icon iconName="RingerSolid" className="ms-IconExample" />
            </div>
            <div className="col-xs-2">
              <Icon iconName="Settings" className="ms-IconExample" />
            </div>
            <div className="col-xs-2">
              <Persona
                {...examplePersona}
                size={PersonaSize.size28}
                presence={PersonaPresence.none}
              />
            </div>
          </div>
        </div>
        <div className="col-xs-12 content">
          <div className="sidenav col-xs-3">
            <div>
              <Icon
                iconName="GlobalNavButton"
                className="ms-IconExample"
                onClick={this.toogleSidenav}
              />
            </div>
            <div ref={this.myRef}>
              <FocusZone>
                <List
                  className="ms-ListGridExample"
                  items={items}
                  onRenderCell={this.onRenderCell}
                />
              </FocusZone>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  const { TimeLoader, displayMsg, notification } = state.collaboratives;
  return {
    TimeLoader,
    displayMsg,
    notification
  };
}

export default connect(mapStateToProps)(Header);
