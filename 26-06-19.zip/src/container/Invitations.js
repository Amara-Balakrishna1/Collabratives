import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import {
  CommandBarButton,
  DefaultButton,
  PrimaryButton
} from "office-ui-fabric-react/lib/Button";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  Persona,
  PersonaSize
  // PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
// import { List } from "office-ui-fabric-react/lib/List";
import { Link } from "react-router-dom";
import {
  DetailsList,
  DetailsRow,
  DetailsListLayoutMode,
  SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import { Label, Modal, Checkbox } from "office-ui-fabric-react";
// import { Callout } from "office-ui-fabric-react/lib/Callout";
// import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { mergeStyleSets } from "office-ui-fabric-react/lib/Styling";
import { InvContent } from '../components/Collabrative'
import "./Invitations.scss";

const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: "16px"
  },
  fileIconCell: {
    textAlign: "center",
    selectors: {
      "&:before": {
        content: ".",
        display: "inline-block",
        verticalAlign: "middle",
        height: "100%",
        width: "0px",
        visibility: "hidden"
      }
    }
  },
  fileIconImg: {
    verticalAlign: "middle",
    maxHeight: "16px",
    maxWidth: "16px"
  },
  controlWrapper: {
    display: "flex",
    flexWrap: "wrap"
  },
  exampleToggle: {
    display: "inline-block",
    marginBottom: "10px",
    marginRight: "30px"
  },
  selectionDetails: {
    marginBottom: "20px"
  }
});
class Invitations extends Component {
  constructor(props) {
    super(props);
    const that = this;

    that.t2 = React.createRef();
    const columns = [
      {
        key: "column1",
        name: "File Type",
        className: classNames.fileIconCell,
        iconClassName: classNames.fileIconHeaderIcon,
        ariaLabel:
          "Column operations for File type, Press to sort on File type",
        iconName: "Page",
        isIconOnly: true,
        fieldName: "name",
        minWidth: 16,
        maxWidth: 16,
        onRender: item => (
          <div>
            <Icon
              style={{ fontSize: "16px" }}
              iconName="Mail"
              className="ms-IconExample"
            />
          </div>
        )
      },
      {
        key: "column2",
        name: "Name",
        fieldName: "name",
        minWidth: 210,
        maxWidth: 230,
        isRowHeader: true,
        isResizable: true,
        isSorted: true,
        isSortedDescending: false,
        sortAscendingAriaLabel: "Sorted A to Z",
        sortDescendingAriaLabel: "Sorted Z to A",
        data: "string",
        isPadded: true,
        onRender: item => (
          <span fontSize="14px" color="#323130">
            {item.name}
          </span>
        )
      },
      {
        key: "column3",
        name: "Received On",
        fieldName: "dateModifiedValue",
        minWidth: 220,
        maxWidth: 280,
        isResizable: true,
        data: "number",
        onRender: item => (
          <span fontSize="12px" color="#797775">
            {item.receivedOn}
          </span>
        ),
        isPadded: true
      },
      {
        key: "column4",
        name: "Sent By",
        fieldName: "modifiedBy",
        minWidth: 210,
        maxWidth: 250,
        isResizable: true,
        isCollapsible: true,
        data: "string",
        onRender: item => (
          <span color="#797775" fontSize="12px">
            {item.sentBy}
          </span>
        ),
        isPadded: true
      },
      {
        key: "column5",
        name: "Action",
        fieldName: "fileSizeRaw",
        minWidth: 150,
        maxWidth: 190,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <CommandBarButton
            iconProps={{ iconName: "CheckMark" }}
            onClick={() => {
              that.setState({
                isOpen: true
              });
            }}
            style={{ background: "none", color: "#0078D4", fontSize: "12px" }}
            text="Accept"
          />
        )
      }
    ];
    this.state = {
      columns,
      items: [
        {
          name: "adsf",
          receivedOn: "dfas",
          sentBy: "asdf",
          action: "asdf"
        },
        {
          name: "adsf",
          receivedOn: "dfas",
          sentBy: "asdf",
          action: "asdf"
        },
        {
          name: "adsf",
          receivedOn: "dfas",
          sentBy: "asdf",
          action: "asdf"
        },
        {
          name: "adsf",
          receivedOn: "dfas",
          sentBy: "asdf",
          action: "asdf"
        },
        {
          name: "adsf",
          receivedOn: "dfas",
          sentBy: "asdf",
          action: "asdf"
        }
      ]
    };
  }
  toggleDialog = () => {
    this.setState({
      isOpen: false
    });
  };
  render() {
    const { items, columns, isOpen } = this.state;
    return (
      <Pivot className="invitations">
        <PivotItem
          itemKey="pivotItemKey_0"
          headerText="Received"
          style={{ height: "100%" }}
          itemCount={2}
        >
          <Modal
            isOpen={isOpen}
            isBlocking={false}
            containerClassName="container inv-modal"
          >
            <div className="header">
              <div className="col-xs-11 text-center">
                <b>Invitation</b>: Fresh Produce(Food Saftey)
              </div>
              <div
                className="col-xs-1 pull-right"
                style={{ textAlign: "right" }}
              >
                <Icon
                  iconName="Cancel"
                  className="ms-IconExample"
                  onClick={this.toggleDialog}
                />
              </div>
            </div>
            <InvContent />
            <footer className="text-center">
              <Checkbox
                label="I agreed to Terms & Conditions, Privacy Policy and Other Documents"
                onChange={(ev, isChecked) => {
                  this.setState({
                    isAgreed: isChecked
                  });
                }}
              />
              <div>
                <PrimaryButton
                  disabled={!this.state.isAgreed}
                  text="Join"
                  onClick={() => {}}
                />
              </div>
            </footer>
          </Modal>
          <Label style={{ padding: "16px", fontSize: "24px" }}>
            Received Invitations
          </Label>
          <div className="row" style={{ margin: "0px", padding: "10px 30px" }}>
            <DetailsList
              selectionMode={SelectionMode.none}
              items={items}
              columns={columns}
            />
          </div>
        </PivotItem>
        <PivotItem
          itemKey="pivotItemKey_1"
          headerText="Sent"
          style={{ height: "100%" }}
        >
          <div className="sample">
            -----------------------In Progress------------------------
          </div>
        </PivotItem>
      </Pivot>
    );
  }
}

export default Invitations;
