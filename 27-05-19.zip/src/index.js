import React from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import { Provider } from "react-redux";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { createStore, applyMiddleware } from "redux";
import thunk from 'redux-thunk';
import { initializeIcons } from "@uifabric/icons";
import reducers from "./reducers";
import Header from "./container/LayoutContainer";
import Collaboratives from "./container/CollaborativesContainer";
import Collaborative from "./container/CollaborativeContainer";
import * as serviceWorker from "./serviceWorker";
import 'office-ui-fabric-react/dist/css/fabric.min.css';
import 'react-super-select/lib/react-super-select.css';
import "./index.scss";

initializeIcons(undefined, { disableWarnings: true });

const Root = ({ store }) => (
  <Provider store={store}>
    <Router>
      <Header className="app-header" />
      <main className="main">
        <Switch>
          <Route exact path="/" component={Collaboratives} />
          <Route exact path="/collaborative" component={Collaborative} />
        </Switch>
      </main>
    </Router>
  </Provider>
);

const middleware = [thunk];

const createStoreWithMiddleware = applyMiddleware(...middleware)(createStore);
const store = createStoreWithMiddleware(reducers);

Root.propTypes = {
  store: PropTypes.object.isRequired
};

// export default Root

ReactDOM.render(<Root store={store} />, document.getElementById("root"));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
