import {
  GET_COLLAborativeS,
  GET_COLLAborativeDETAILS
} from "../actions/collaborativesActions";

export default function visibilityFilter(state = {}, action) {
  switch (action.type) {
    case GET_COLLAborativeS: {
      const { data = [], industries = [], formats = [] } = action;
      return { ...state, collaboratives: data, industries, formats };

    }
    case GET_COLLAborativeDETAILS:
      return {
        ...state,
        collaborativeDetail: action.data
      };
    default:
      return state;
  }
}
