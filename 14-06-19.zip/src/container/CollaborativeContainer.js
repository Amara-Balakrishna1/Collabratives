import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import {
  CommandBarButton,
  DefaultButton
} from "office-ui-fabric-react/lib/Button";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  Persona,
  PersonaSize
  // PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
// import { List } from "office-ui-fabric-react/lib/List";
import { Link } from "react-router-dom";
import {
  DetailsList,
  DetailsRow,
  DetailsListLayoutMode,
  SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
// import { Callout } from "office-ui-fabric-react/lib/Callout";
// import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { mergeStyleSets } from "office-ui-fabric-react/lib/Styling";

import {
  Adddata,
  InviteOrganization,
  AddMembers
} from "../components/Collabrative";
import {
  getCollaborativeDetail,
  postData
} from "../actions/collaborativesActions";
import "./CollaborativeContainer.scss";

// const uuidv1 = require("uuid/v1");s

const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: "16px"
  },
  fileIconCell: {
    textAlign: "center",
    selectors: {
      "&:before": {
        content: ".",
        display: "inline-block",
        verticalAlign: "middle",
        height: "100%",
        width: "0px",
        visibility: "hidden"
      }
    }
  },
  fileIconImg: {
    verticalAlign: "middle",
    maxHeight: "16px",
    maxWidth: "16px"
  },
  controlWrapper: {
    display: "flex",
    flexWrap: "wrap"
  },
  exampleToggle: {
    display: "inline-block",
    marginBottom: "10px",
    marginRight: "30px"
  },
  selectionDetails: {
    marginBottom: "20px"
  }
});
// const controlStyles = {
//   root: {
//     margin: '0 30px 20px 0',
//     maxWidth: '300px'
//   }
// };

// const examplePersona = {
//   // imageUrl: TestImages.personaFemale,
//   imageInitials: "AL",
//   text: "Annie Lindqvist",
//   secondaryText: "Software Engineer",
//   tertiaryText: "In a meeting",
//   optionalText: "Available at 4:00pm"
// };

class Collaborative extends Component {
  constructor(props) {
    super(props);
    const that = this;

    that.t2 = React.createRef();
    const columns = [
      {
        key: "column1",
        name: "File Type",
        className: classNames.fileIconCell,
        iconClassName: classNames.fileIconHeaderIcon,
        ariaLabel:
          "Column operations for File type, Press to sort on File type",
        iconName: "Page",
        isIconOnly: true,
        fieldName: "name",
        minWidth: 16,
        maxWidth: 16,
        onRender: item => (
          <div>
            <Icon
              style={{ fontSize: "16px" }}
              iconName={
                item.status === "Pending" ? "RepeatAll" : "FabricFolderFill"
              }
              className="ms-IconExample"
            />
          </div>
        )
      },
      {
        key: "column2",
        name: "Name",
        fieldName: "name",
        minWidth: 110,
        maxWidth: 130,
        isRowHeader: true,
        isResizable: true,
        isSorted: true,
        isSortedDescending: false,
        sortAscendingAriaLabel: "Sorted A to Z",
        sortDescendingAriaLabel: "Sorted Z to A",

        data: "string",
        isPadded: true
      },
      {
        key: "column3",
        name: "Description",
        fieldName: "dateModifiedValue",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        data: "number",
        onRender: (item, index) => {
          return (
            <Icon
              iconName="Info"
              className="ms-IconExample"
              // ref={this[`t${index}`]}
              onMouseOver={event => {
                that.setState({
                  isCalloutVisible: true,
                  callDescription: `${item.description}${index}`,
                  callFrame: `${moment(item.dataStartDate).format(
                    "MMM-YYYY"
                  )}-${moment(item.dataEndDate).format("MMM-YYYY")}`,
                  top: event.clientY - 125,
                  left: event.clientX - 155
                });
              }}
              onMouseLeave={() => {
                this.setState({
                  isCalloutVisible: false
                });
              }}
            />
          );
        },
        isPadded: true
      },
      {
        key: "column4",
        name: "Shared By",
        fieldName: "modifiedBy",
        minWidth: 110,
        maxWidth: 150,
        isResizable: true,
        isCollapsible: true,
        data: "string",
        onRender: item => <span>{that.getName(item.ownerId)}</span>,
        isPadded: true
      },
      {
        key: "column5",
        name: "Size",
        fieldName: "fileSizeRaw",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => <span>{item.sizeInGB}</span>
      },
      {
        key: "column6",
        name: "Last Modified",
        fieldName: "fileSizeRaw",
        minWidth: 100,
        maxWidth: 120,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <span>
            {moment(item.lastModified).format("ddd DD-MMM-YYYY hh:mm A")}
          </span>
        )
      },
      {
        key: "column13",
        name: "Location",
        // className: classNames.fileIconCell,
        // iconClassName: classNames.fileIconHeaderIcon,
        // ariaLabel:
        //   "Column operations for File type, Press to sort on File type",
        // iconName: "Page",
        // isIconOnly: true,
        fieldName: "name",
        minWidth: 120,
        maxWidth: 160,
        onRender: item => (
          <Link to="/subscriptions/b2251f1c-ceaa-4">
            /subscriptions/b2251f1c-ceaa-4
          </Link>
        )
      },
      {
        key: "column7",
        name: "Status",
        fieldName: "fileSizeRaw",
        minWidth: 90,
        maxWidth: 130,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <>
            {item.status === "Pending" ? (
              <DefaultButton
                text="Import"
                style={{ width: "125px", marginBottom: 10 }}
              />
            ) : (
              <DefaultButton
                className="column"
                text={item.status}
                style={{ width: "125px" }}
              />
            )}
            <Icon
              style={{ fontSize: "16px", marginTop: 5 }}
              iconName="MoreVertical"
              className="ms-IconExample"
              onClick={event => {
                console.log("a");
                const { nativeEvent } = event;
                this.setState({
                  isStatusCalloutVisible: true,
                  statusTop: nativeEvent.clientY - 125,
                  statusLeft: nativeEvent.clientX - 155
                });
              }}
            />
          </>
        )
      }
      // {
      //   key: "column11",
      //   name: "File Type",
      //   className: classNames.fileIconCell,
      //   iconClassName: classNames.fileIconHeaderIcon,
      //   ariaLabel:
      //     "Column operations for File type, Press to sort on File type",
      //   iconName: "Page",
      //   isIconOnly: true,
      //   fieldName: "name",
      //   minWidth: 16,
      //   maxWidth: 16,
      //   onRender: item => (
      //     <div>
      //       <Icon
      //         style={{ fontSize: "16px" }}
      //         iconName="MoreVertical"
      //         className="ms-IconExample"
      //       />
      //     </div>
      //   )
      // }
    ];
    const { collaborationId } = props.match.params;
    this.state = {
      collaborationId,
      columns
    };
  }
  componentDidMount() {
    const { getCollaborativeDetail } = this.props;
    const { collaborationId } = this.state;
    getCollaborativeDetail(collaborationId);
  }
  static getDerivedStateFromProps(nextProps) {
    const { activityLog = [], dataSets = [] } = Object(
      nextProps.collaborativeDetail
    );
    return {
      items: dataSets || [],
      activityLog
    };
  }
  onRenderRow = props => {
    return (
      <DetailsRow
        {...props}
        styles={{
          root: {
            backgroundColor: props.item.status === "Pending" ? "#FFF4CE" : ""
          }
        }}
      />
    );
  };
  getName = (id, log) => {
    const { collaborators = [] } = this.props.collaborativeDetail;
    const obj = collaborators.filter(d => d.id === id)[0] || {};
    if (log) {
      return `${obj.organizationName}(${obj.fullName})` || "";
    }
    return `${obj.fullName}(${obj.emailId})` || "";
  };
  getInitials(name = "") {
    const arr = name ? name.split(".") : [[], []];
    return `${(arr[0][0] || "").toUpperCase()}${(
      arr[1][0] || ""
    ).toUpperCase()}`;
  }
  toggleNav = tabName => {
    this.setState({
      [tabName]: !this.state[tabName]
    });
  };
  postDataSet = (collaborationId, data) => {
    this.props.postData(collaborationId, data);
    this.setState({
      showAMember: false,
      showIOrganization: false,
      showAddData: false
    });
  };
  render() {
    const {
      columns,
      isCompactMode,
      items,
      isModalSelection,
      activityLog,
      isCalloutVisible,
      isStatusCalloutVisible,
      callDescription,
      callFrame,
      top,
      left,
      statusLeft,
      statusTop,
      showAddData,
      showAMember,
      showIOrganization,
      collaborationId
    } = this.state;
    const { collaborativeDetail } = this.props;
    const { collaborators = [], information = {} } = Object(
      collaborativeDetail
    );
    const admin =
      collaborators.filter(d => d.userRole === "CollaborativeAdmin")[0] || {};
    const nonAdmin = collaborators.filter(
      d => d.userRole !== "CollaborativeAdmin"
    );
    const showRightNav = showAddData || showAMember || showIOrganization;
    return (
      <div className="detail-collabarative">
        <div className="col-xs-12 addRow">
          <div className="col-xs-11">
            {isCalloutVisible && (
              <div
                className="ms-CalloutExample-callout"
                style={{
                  zIndex: 99,
                  position: "fixed",
                  top,
                  left
                }}
              >
                <div>{callDescription}</div>
                <div>
                  <b>Time Frame: </b>
                  {callFrame}
                </div>
              </div>
            )}
            {isStatusCalloutVisible && (
              <div
                className="ms-CalloutExample-callout"
                style={{
                  zIndex: 99,
                  position: "fixed",
                  top: statusTop,
                  left: statusLeft
                }}
              >
                <div>{callDescription}</div>
                <div>
                  <b>Time Frame: </b>
                  {callFrame}
                </div>
              </div>
            )}

            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={() => {
                this.setState({
                  showAddData: true,
                  showIOrganization: false,
                  showAMember: false
                });
              }}
              text="Add Data"
            />

            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={() => {
                this.setState({
                  showIOrganization: true,
                  showAddData: false,
                  showAMember: false
                });
              }}
              text="Invite Organization"
            />
            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={() => {
                this.setState({
                  showAMember: true,
                  showIOrganization: false,
                  showAddData: false
                });
              }}
              text="Add Members"
            />
          </div>
          {/* <div className="col-xs-1">
            <Icon iconName="Info" className="ms-IconExample" />
          </div> */}
        </div>
        <div className="col-xs-12 collabInfo">
          <div className="col-xs-7">
            <Persona
              imageUrl={information.imageUrl}
              text={information.name}
              secondaryText={information.defaultAzureStorageLocation}
              size={PersonaSize.size72}
              onRenderPrimaryText={data => (
                <div style={{ fontSize: "24px" }}>
                  <span>{data.text} </span>
                  <a style={{ fontSize: "14px" }} href="javascript:void(0)">
                    {" "}
                    View Detail
                  </a>
                </div>
              )}
              onRenderSecondaryText={data => (
                <div>
                  <b>Default Location: </b>
                  {(data.secondaryText || "").substring(0, 30)}...
                  <CommandBarButton
                    className="detail-persona"
                    iconProps={{ iconName: "Edit" }}
                    onClick={() => {
                      console.log("adfasd");
                    }}
                    text="Edit"
                  />
                </div>
              )}
            />
          </div>
          <div className="col-xs-5 ">
            <div className="persons">
              <div className="col-xs-3">Collaborative Admin:</div>
              <div className="col-xs-9">
                <Persona
                  text={
                    admin.fullName
                      ? `${admin.fullName} (${admin.organizationName})`
                      : ""
                  }
                  size={PersonaSize.size32}
                  imageInitials={this.getInitials(admin.userName)}
                />
              </div>
            </div>
            <div className="persons">
              <div className="col-xs-3">Collaborators({nonAdmin.length}):</div>
              <div className="col-xs-9 persona-list">
                {nonAdmin.map(item => (
                  <Persona
                    key={`${item.userName}-12`}
                    {...item}
                    size={PersonaSize.size32}
                    imageInitials={this.getInitials(item.userName)}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="col-xs-12 dataInfo">
          <div className="col-xs-9 data-container">
            <div className="col-xs-12 data">
              <div className="col-xs-4">
                <div className="storage-details">0</div>
                <div className="storage-label">GB of Data</div>
              </div>
              <div className="col-xs-4">
                <div className="storage-details">0</div>
                <div className="storage-label">Members</div>
              </div>
              {/* <div className="col-xs-3">
                <div className="storage-details" >&nbsp;</div>
                <div className="storage-label">
                  Volume Trends
                </div>
              </div> */}
              <div className="col-xs-4">
                <div className="storage-details">0</div>
                <div className="storage-label">Models</div>
              </div>
            </div>
            <div
              className="col-xs-12"
              style={{
                fontFamily: "Segoe UI",
                fontSize: "20px",
                height: "52px",
                padding: "0px 10px"
              }}
            >
              Collaborative Data
            </div>
            <div className="col-xs-12 dataList">
              <DetailsList
                items={items}
                compact={isCompactMode}
                columns={columns}
                selectionMode={
                  isModalSelection ? SelectionMode.multiple : SelectionMode.none
                }
                onRenderRow={this.onRenderRow}
                setKey="set"
                layoutMode={DetailsListLayoutMode.justified}
                isHeaderVisible
                ariaLabelForSelectionColumn="Toggle selection"
                ariaLabelForSelectAllCheckbox="Toggle selection for all items"
              />
            </div>
          </div>
          <div className="col-xs-3 activity-container">
            <div className="col-xs-12" style={{ padding: "18px 15px" }}>
              <b className="heading">Activity</b>
              <Link to="activityLog" className="pull-right">
                Detail view
              </Link>
            </div>
            <div className="col-xs-12">
              {activityLog.map((d, i) => (
                <div className="activityLog" key={`test-${i}`}>
                  <div>
                    <b>{this.getName(d.userId, true)}</b>
                  </div>
                  {d.actionInformation}
                  <span color="green">-</span>
                  <div>
                    on {moment(d.timeStamp).format("ddd DD-MMM-YYYY hh:mm A")}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className={`${showRightNav ? "show" : ""} addData`}>
          {showAddData && (
            <Adddata
              toggleData={this.toggleNav}
              postData={this.postDataSet}
              collaborationId={collaborationId}
            />
          )}
          {showIOrganization && (
            <InviteOrganization toggleData={this.toggleNav} />
          )}
          {showAMember && <AddMembers toggleData={this.toggleNav} />}
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log(state);
  const { collaborativeDetail } = state.collaboratives;
  return {
    collaborativeDetail
  };
}

function mapDispatchToProps(dispatch) {
  return {
    getCollaborativeDetail: collaborationId =>
      dispatch(getCollaborativeDetail(collaborationId)),
    postData: (collaborationId, data) =>
      dispatch(postData(collaborationId, data))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Collaborative);
