import React, { Component } from "react";
import { Label } from "office-ui-fabric-react/lib/Label";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton, Dropdown } from "office-ui-fabric-react";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  CommandBarButton,
  DefaultButton
} from "office-ui-fabric-react/lib/Button";
import Wrapper from "./Addwrapper";
import Fileinput from "../Collaboratives/Fileinput";
import "./InviteOrganization.scss";

class InviteOrganization extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formFields: {
        Organization: "",
        otherOrganization: "",
        adminName: "",
        adminEmail: ""
      },
      tcArray: [
        {
          documentName: "Terms and Conditions"
        },
        {
          documentName: "Privacy Policy"
        }
      ],
      newFields: []
    };
  }
  render() {
    const { toggleData, subscription = "" } = this.props;
    const { tcArray, newFields } = this.state;
    return (
      <Wrapper toggleData={toggleData} name="showIOrganization">
        <div
          className="row IO"
          style={{
            height: "90%",
            padding: "20px",
            margin: "0px",
            overflow: "auto"
          }}
        >
          <Label>Invite Organization</Label>
          <Dropdown
            label="Select Organization"
            options={[
              { key: "apple", text: "Apple" },
              { key: "banana", text: "Banana" },
              { key: "orange", text: "Orange" },
              { key: "grape", text: "Grape" },
              { key: "others", text: "others" }
            ]}
          />
          <TextField
            label="Organization Name"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
          <TextField
            label="Organization Admin Name"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
          <TextField
            label="Organization Admin Email"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
          <Label>Collaborative Legal Document</Label>
          {tcArray.map((d, i) => (
            <div className="row">
              <div className="collab-field">
                <div className="ms-TextField-wrapper">
                  {/* <div className="ms-Stack">{d.name}</div> */}

                  <Stack horizontal verticalAlign="center">
                    <span>{d.documentName}</span>
                  </Stack>
                  <div
                    className="ms-TextField-fieldGroup"
                    style={{ border: "none" }}
                  >
                    <Fileinput
                      root="tcArray"
                      label={d.documentName}
                      id={`tc-${i}`}
                      index={i}
                      fileChange={this.fileChange}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div className="col-xs-12" style={{ padding: "20px 10px" }}>
            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              style={{ background: "none", color: "#0078D4" }}
              onClick={() => {
                newFields.push({});
                this.setState({
                  newFields
                });
              }}
              text="Add additional organization specific documents"
            />
          </div>
          {newFields.length ? (
            <div className="newFields">
              {newFields.map((d, i) => (
                <div className="row moreField">
                  <div className="collab-field">
                    <TextField
                      value={d.documentName}
                      onChange={(ev, value) => {
                        this.setTCName(i, value);
                      }}
                      // required
                      placeholder="Ex. Label"
                    />
                    <Fileinput
                      root="newFields"
                      label={d.documentName}
                      // url={d.documentUrl}
                      id={`nf-${i}`}
                      index={i}
                      fileChange={this.fileChange}
                    />
                    <DefaultButton
                      className="pull-right removeButton"
                      // iconProps={{ iconName: "Add" }}
                      style={{ background: "none", color: "#0078D4" }}
                      onClick={() => {
                        newFields.splice(i, 1);
                        this.setState({
                          newFields
                        });
                      }}
                      text="remove"
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </div>

        <div className="row" style={{ padding: "20px", margin: "0px" }}>
          <PrimaryButton text="Invite Organization" />
        </div>
      </Wrapper>
    );
  }
}

export default InviteOrganization;
