import axios from "axios";
import config from "./config";
import urls from "./actionURLS";

export const GET_COLLAborativeS = "GET_COLLAborativeS";
export const GET_COLLAborativeDETAILS = "GET_COLLAborativeDETAILS";
export const MANAGE_NOTIFICATION = "MANAGE_NOTIFICATION";

const errorTxt = "ERROR";
const success = "SUCCESS";

export function onLoader() {
  return {
    notification: "",
    TimeLoader: true,
    displayMsg: "",
    type: MANAGE_NOTIFICATION
  };
}

export function offLoader(notification, displayMsg) {
  return {
    notification,
    TimeLoader: false,
    displayMsg,
    type: MANAGE_NOTIFICATION
  };
}

export function getCollaboratives() {
  const arr = [
    axios.get(`${urls.getAllCollaboratives}`, config),
    axios.get(`${urls.getIndustries}`, config),
    axios.get(`${urls.getFormats}`, config)
  ];
  return dispatch => {
    axios
      .all(arr)
      .then(
        axios.spread((list, industries, formats) => {
          dispatch({
            type: GET_COLLAborativeS,
            data: list.data,
            industries: industries.data,
            formats: formats.data
          });
        })
      )
      .catch();
  };
}

export function getCollaborativeDetail(collaborationId) {
  return dispatch => {
    console.log(`${urls.getCollaborativeInfo}${collaborationId}`);
    axios
      .get(`${urls.getCollaborativeInfo}${collaborationId}`, config)
      .then(result => {
        dispatch({
          type: GET_COLLAborativeDETAILS,
          data: result.data
        });
      })
      .catch(err => {
        console.log("error");
      });
  };
}

export function createCollaborative(data) {
  return dispatch => {
    // console.log(dispatch, data);
    axios
      .post(`${urls.postCollaboration}`, data, config)
      .then(result => {
        // dispatch({
        //   type: GET_COLLAborativeDETAILS,
        //   data: result.data
        // });
        // console.log(result, data);
        dispatch(getCollaboratives());
      })
      .catch(err => {
        alert(err.response.data.message);
        console.log("error");
      });
  };
}

export function postData(collaborationId, data) {
  return dispatch => {
    dispatch(onLoader());
    axios
      .post(`${urls.postData}${collaborationId}/datasets`, data, config)
      .then(result => {
        dispatch(getCollaborativeDetail(collaborationId));
        dispatch(offLoader(success, result.data));
      })
      .catch(err => {
        dispatch(offLoader(errorTxt, err.response.data.message));
      });
  };
}
