import ActionConfig from '../actions/actionConfig';

const initialState = {
  nodes: [],
  links: []
};

export default function userReducer(state = initialState, action) {
  
  switch (action.type) {
    case ActionConfig.detailInfo:
      return  { ...state, ...action.data} ;
    default:
      return state;
  }
}
