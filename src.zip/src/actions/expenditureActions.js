import ActionConfigs from './actionConfig';

const serverURL = 'http://localhost:3000/';

export function detailInfo(detail) {
  return (dispatch) => {
    fetch(`${serverURL}data.json`, ActionConfigs)
    .then(res => res.json())
    .then(data => {
        dispatch({
          type: ActionConfigs.detailInfo,
          data
        });
      });
  };
}

export function updateField(data) {
 return (dispatch, getState) => {
   getState().data.links.forEach(d => {
     if(d.target.index === data.index) {
       d.value = parseInt(data.value, 10);
     }
   })
   dispatch({
     type: ActionConfigs.detailInfo,
     data : {
       links : getState().data.links
     }
   })
 }
}

export function removeField(data) {
  return (dispatch, getState) => {
    dispatch({
      type: ActionConfigs.detailInfo,
      data: {
        nodes: getState().data.nodes.filter(d => d.name !== data.name),
        links: getState().data.links.filter(d => d.target.index !== data.index)
      }
    })
  }
}


export function addField(data) {
  return (dispatch, getState) => {
    dispatch({
      type: ActionConfigs.detailInfo,
      data: {
        nodes: [ ...getState().data.nodes, {name: data.name}],
        links: [...getState().data.links, {source: 0, target: getState().data.nodes.length , value: parseInt(data.value, 10)}]
      }
    })
  }
}