const ActionConfigs = {
  detailInfo: 'DETAILINFO',
  updateField: 'UPDATEFIELD',
  removeField: "REMOVEFIELDS",
  addField: 'ADDFIELD'
};

export default ActionConfigs;
