import React from "react";
import { Header, Chartcontainer } from './containers'
import "./i18n";
import "./App.css";

function App() {
  return (
    <>
     <Header />
     <Chartcontainer />
    </>
  )
}

export default App;
