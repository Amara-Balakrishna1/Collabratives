import React, { Component } from "react";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { DefaultButton } from "office-ui-fabric-react/lib/Button";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";

import "./modalStyle.scss";

class AddCollab extends Component {
  state = {
    formFields: {}
  };
  createTextField = (label, value) => {
    return (
      <TextField
        label={label}
        value={value}
        onChange={this.onChange}
        className="collab-field"
      />
    );
  };
  // toggleDialog = () => {
  //   const { showDialog } = this.state;
  //   this.setState({
  //     showDialog: !showDialog
  //   });
  // };
  render() {
    const { showDialog, toggleDialog } = this.props;
    const {
      formFields: {
        collaborativeName,
        goal,
        selectedIndustry,
        context,
        storageLocation,
        format,
        terms
      }
    } = this.state;
    return (
      <Modal
        isOpen={showDialog}
        isBlocking={false}
        containerClassName="container"
      >
        <div className="header">
          <div className="col-xs-11">Create Collaborative</div>
          <div className="col-xs-1 pull-right" style={{ textAlign: "right" }}>
            <Icon
              iconName="Cancel"
              className="ms-IconExample"
              onClick={toggleDialog}
            />
          </div>
        </div>
        <div className="row">
          <Pivot className="tabHeader">
            <PivotItem headerText="Collabrative Details">
              <div className="col-xs-12">
                {this.createTextField("Collaborative Name", collaborativeName)}
              </div>
              <div className="col-xs-12">
                {this.createTextField("Select Industry", selectedIndustry)}
              </div>
              <div className="col-xs-12">
                {this.createTextField("Goal", goal)}
              </div>
              <div className="col-xs-12">
                {this.createTextField("Data context", context)}
              </div>
              <div className="col-xs-12">
                {this.createTextField(
                  "Default Storage Location",
                  storageLocation
                )}
              </div>
              <div className="col-xs-12">
                {this.createTextField("Recommended Format", format)}
              </div>
            </PivotItem>
            <PivotItem headerText="Terms of Use">
              <div className="col-xs-12">Pivot #3</div>
            </PivotItem>
          </Pivot>
        </div>
        <div>
          <DefaultButton text="Continue" />
        </div>
      </Modal>
    );
  }
}

export default AddCollab;
