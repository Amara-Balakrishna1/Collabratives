import React, { useState, useEffect, useReducer } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from "react-i18next";
import { detailInfo, updateField, removeField, addField } from "../actions/expenditureActions";
import Sankey from "./sankey";



function Chartcontainer() {
  const { t } = useTranslation();
  const data = useSelector(state => state.data, []);
  const [removeData, setRemoveData] = useState(null);
  const nameRef = React.createRef();
  const valueRef = React.createRef();
  const [appMode, setAppMode] = useState({ edit: false, remove: false, add: false });
  const dispatch = useDispatch()
  useEffect(() => {
    if (!data.nodes.length)
      dispatch(detailInfo())
  }, [])
  console.log(data);
  return (
    <div className="App">
      <div className="content1">
        <div>
          <button onClick={() => setAppMode({ edit: true, remove: false, add: false })}>{t("Edit Data")}</button>
          <button onClick={() => setAppMode({ edit: false, remove: true, add: false })}>{t("Remove Data")}</button>
          <button onClick={() => setAppMode({ edit: false, remove: false, add: true })}>{t("Add Data")}</button>

        </div>
        <div className="options">
          {
            appMode.remove && (<>
              <select onChange={event => {
                const name = event.nativeEvent.target.value;
                const index = event.nativeEvent.target.selectedOptions[0].index;
                setRemoveData({ name, index })
              }
              }>
                <option disabled selected value> -- select an option -- </option>{
                  data.nodes.map((d, i) => i ? <option value={d.name} index={d.index} key={`test - ${i}`}>{t(d.name)}</option> : null)
                }</select>
              <button onClick={() => dispatch(removeField(removeData))}> Remove</button>
            </>)
          }
          {
            appMode.add && (
              <div textalign="left">
                <label width="150px" htmlFor="fname">Expense name</label><br />
                <input type="text" ref={nameRef} id="fname" name="fname" /><br />
                <label htmlFor="lname" width="150px">Value</label><br />
                <input type="number" id="lname" ref={valueRef} name="lname" /><br />
                <button onClick={() => dispatch(addField({ name: nameRef.current.value, value: valueRef.current.value }))} >Add Data</button>

              </div>
            )
          }
          {
            appMode.edit && (<>
              <select onChange={event => {
                const name = event.nativeEvent.target.value;
                const index = event.nativeEvent.target.selectedOptions[0].index;
                setRemoveData({ name, index })
              }
              }>
                <option disabled selected value> -- select an option -- </option>{
                  data.nodes.map((d, i) => i ? <option value={d.name} index={d.index} key={`test - ${i}`}>{t(d.name)}</option> : null)
                }</select>
              <br />
              <label htmlFor="lname" width="150px">Value</label><br />
              <input type="number" id="lname" ref={valueRef} name="lname" /><br />
              <button onClick={() => dispatch(updateField({ index: removeData.index, value: valueRef.current.value }))}> Update</button>
            </>)
          }
        </div>
      </div>
      <div className="content2"><Sankey data={data} /></div>
    </div>
  );
}

export default Chartcontainer;
