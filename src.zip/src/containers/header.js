/* global i18n */
import React from 'react';
import Logo from './images/centime-logo.png'
import i18n from "i18next";

const changeLanguage = lng => {
  i18n.changeLanguage(lng);
};

const Header = () => (
  <div className="header">
    <button onClick={() => changeLanguage("en")}>en</button>
    <button onClick={() => changeLanguage("te")}>te</button>
    <button onClick={() => changeLanguage("hin")}>hin</button>
    <img alt="Celtime" src={Logo} />
  </div>
)
export default Header;