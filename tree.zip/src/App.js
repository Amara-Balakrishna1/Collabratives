import React from "react";
import axios from "axios";
import {
  Fabric,
  PrimaryButton,
  DetailsList,
  SelectionMode,
  Selection
} from "office-ui-fabric-react";
let additionalColumns = 15;

const _blueGroupIndex = 2;
export default class Content extends React.Component {
  constructor(props) {
    super(props);
    this._root = React.createRef();
    this.state = {
      items: [
        { key: "a", name: "a", color: "red" },
        { key: "b", name: "b", color: "red" },
        { key: "c", name: "c", color: "blue" },
        { key: "d", name: "d", color: "blue" },
        { key: "e", name: "e", color: "blue" }
      ],
      // This is based on the definition of items
      groups: [
        { key: "groupred0", name: 'Color: "red"', startIndex: 0, count: 2 },
        { key: "groupgreen2", name: 'Color: "green"', startIndex: 2, count: 0 },
        { key: "groupblue2", name: 'Color: "blue"', startIndex: 2, count: 3 }
      ],
      showItemIndexInView: false,
      isCompactMode: false
    };

    this._columns = [
      {
        key: "name",
        name: "Name",
        fieldName: "name",
        minWidth: 100,
        maxWidth: 200,
        isResizable: true
      },
      {
        key: "color",
        name: "Color",
        fieldName: "color",
        minWidth: 100,
        maxWidth: 200
      }
    ];
  }
  _getSelectionDetails() {
    const selectionCount = this.selection.getSelectedCount();

    switch (selectionCount) {
      case 0:
        return 'No items selected';
      case 1:
        return '1 item selected: ' + (this.selection.getSelection()[0]).name;
      default:
        return `${selectionCount} items selected`;
    }
  }
  _addItem = () => {
    const items = this.state.items;
    const groups = [...this.state.groups];
    groups[_blueGroupIndex].count++;

    this.setState(
      {
        items: items.concat([
          {
            key: "item-" + items.length,
            name: "New item " + items.length,
            color: "blue"
          }
        ]),
        groups
      },
      () => {
        if (this._root.current) {
          this._root.current.focusIndex(items.length, true);
        }
      }
    );
  };
  selection = new Selection({
    onSelectionChanged: () => {
      this.setState({
        selectionDetails: this._getSelectionDetails()
      });
    }
  });
  render() {
    let { items, groups } = this.state;
    return (
      <Fabric>
        <PrimaryButton
          style={{ position: "fixed", zIndex: 1, top: 0, right: 0 }}
          onClick={() => this._addItem()}
          text="Add an item"
        />

        <DetailsList
          selectionMode={SelectionMode.multiple}
          componentRef={this._root}
          onShouldVirtualize={() => false}
          items={items}
          selectionPreservedOnEmptyClick
          selection={this.selection}
          columns={this._columns}
          onItemContextMenu={(item, index) => alert(item)}
        />
      </Fabric>
    );
  }

  addItem() {
    let items = this.state.items;

    this.setState({
      items: [
        {
          key: "item-" + items.length,
          name: "New item " + items.length,
          color: "red"
        }
      ].concat(items)
    });
  }
}
