import React from "react";
import ReactDOM from "react-dom";
import { initializeIcons } from "@uifabric/icons";
import { registerIcons } from "office-ui-fabric-react/lib/Styling";
import "./index.css";
import App from "./tree";
import * as serviceWorker from "./serviceWorker";
// import * as Msal from 'msal';
initializeIcons(undefined, { disableWarnings: true });

registerIcons({
  icons: {
    browserExperience: (
        <svg xmlns="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 20 20" version="1.1">
        <title>i-20x20-azure_blob</title>
        <desc>Created with Sketch.</desc>
        <defs/>
        <g id="i-20x20-azure_blob" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
            <path d="M3,15.468 C3,15.748 3.224,16 3.504,16 L16.468,16 C16.748,16 17,15.776 17,15.468 L17,6.2 L3,6.2 L3,15.468 Z" id="Shape" fill="#A0A1A2" fillRule="nonzero"/>
            <path d="M16.468,4 L3.504,4 C3.224,4 3,4.26052632 3,4.55 L3,6.2 L17,6.2 L17,4.55 C17,4.26052632 16.776,4 16.468,4" id="Shape" fill="#7A7A7A" fillRule="nonzero"/>
            <rect id="Rectangle-path" fill="#0072C6" fillRule="nonzero" x="4" y="7.2" width="5.8" height="3.6"/>
            <rect id="Rectangle-path" fill="#0072C6" fillRule="nonzero" x="4" y="11.4" width="5.8" height="3.6"/>
            <rect id="Rectangle-path" fill="#FFFFFF" fillRule="nonzero" x="10.2" y="7.2" width="5.6" height="3.6"/>
            <rect id="Rectangle-path" fill="#0072C6" fillRule="nonzero" x="10.2" y="11.4" width="5.6" height="3.6"/>
            <path d="M3.55963303,4 C3.25183486,4 3,4.25352113 3,4.56338028 L3,6.61971831 L3,7.54929577 L3,15.4366197 C3,15.7464789 3.25183486,16 3.55963303,16 L4.17522936,16 L15.2,4 L3.55963303,4 Z" id="Shape" fill="#FFFFFF" fillRule="nonzero" opacity="0.2"/>
        </g>
    </svg> )
  }
});

ReactDOM.render(<App />, document.getElementById("root"));
serviceWorker.unregister();
