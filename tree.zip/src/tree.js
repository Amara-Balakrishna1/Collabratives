import React from "react";
import CheckboxTree from "react-checkbox-tree";
import "react-checkbox-tree/lib/react-checkbox-tree.css";
import { Icon, IconType } from 'office-ui-fabric-react/lib/Icon';
import Axios from "axios";
import "./tree.scss"

const subscriptions =
  "https://collaborativesfunctionsforpm.azurewebsites.net/api/users/810917c0-9083-4afa-b783-caa9010dc806/subscriptions";
const resourcegroupsurl =
  "https://collaborativesfunctionsforpm.azurewebsites.net/api/users/810917c0-9083-4afa-b783-caa9010dc806/subscriptions/b2251f1c-ceaa-4ea2-bdfb-7adec3f037de/resourcegroups";
const storageaccountsurl =
  "https://collaborativesfunctionsforpm.azurewebsites.net/api/users/810917c0-9083-4afa-b783-caa9010dc806/subscriptions/b2251f1c-ceaa-4ea2-bdfb-7adec3f037de/resourcegroups/collaboratives-consumer/storageaccounts";

// label
// value
// children
// className
// disabled
// icon
// showCheckbox
// title

// const nodes = [{
//     value: 'mars',
//     label: 'Mars',
//     children: [
//         { value: 'phobos', label: 'Phobos' },
//         { value: 'deimos', label: 'Deimos' },
//     ],
// }]

class Widget extends React.Component {
  state = {
    checked: [],
    expanded: []
  };
  componentDidMount() {
    Axios.get(subscriptions).then(result => {
      this.setState({
        nodes: (result.data || []).map(d => ({
            label:d.resourceName,
            value: d.subscriptionId,
            children:[{children: []}],
            className:"subscriptions",
            // disabled
            icon: <Icon iconName="browserExperience" className="ms-IconExample" />,
            showCheckbox: false
            // title
        }))
      });
    });
  }
  render() {
    const { nodes = [] } = this.state;
    return (
      <CheckboxTree
        nodes={nodes}
        checked={this.state.checked}
        expanded={this.state.expanded}
        onCheck={checked => {
          console.log(checked);
        }}
        onExpand={(expanded, targetNode) => {
          console.log(expanded, targetNode);
        }}
        icons={{
          check: <span className="rct-icon rct-icon-check" />,
          uncheck: <span className="rct-icon rct-icon-uncheck" />,
          halfCheck: <span className="rct-icon rct-icon-uncheck" />,
          expandClose: <span className="fa fa-caret-right" />,
          expandOpen: <span className="fa fa-caret-down" />,
          expandAll: <span className="rct-icon rct-icon-expand-all" />,
          collapseAll: <span className="rct-icon rct-icon-collapse-all" />,
          parentClose: <span className="rct-icon rct-icon-parent-close" />,
          parentOpen: <span className="rct-icon rct-icon-parent-open" />,
          leaf: <span className="rct-icon rct-icon-parent-close" />
        }}
      />
    );
  }
}

export default Widget;
