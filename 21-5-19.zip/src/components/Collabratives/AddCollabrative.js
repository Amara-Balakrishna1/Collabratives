/* global $ */

import React, { Component } from "react";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { DefaultButton } from "office-ui-fabric-react/lib/Button";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { CommandBarButton } from "office-ui-fabric-react/lib/Button";
import ReactSuperSelect from "react-super-select";
import DummyImg from "../../images/Dummy_flag.png";
// import "./rss.scss";
import "./modalStyle.scss";

var file1 = $("#file1").val();

$("#file-upload").on("change.bs.fileinput", function(e, file) {
  //console.log(e)
  $("#file1").val(file1);
});

$("#file-upload").on("clear.bs.fileinput", function(e, file) {
  //console.log(e)
  $("#file1").val(file1);
});

class AddCollab extends Component {
  state = {
    formFields: {},
    tcArray: [
      {
        name: "Terms and Conditions"
      },
      {
        name: "Privacy Policy"
      }
    ]
  };

  createTextField = (label, value, required, placeholder, multiline) => {
    // return (
    //   <TextField
    //     label={label}
    //     value={value}
    //     onChange={this.onChange}
    //     required={required}
    //     placeholder={placeholder}
    //     className="collab-field"
    //     onRenderLabel={this.onRenderDescription}
    //     multiline={multiline}
    //   />
    // );
    return null;
  };
  // toggleDialog = () => {
  //   const { showDialog } = this.state;
  //   this.setState({
  //     showDialog: !showDialog
  //   });
  // };
  onRenderDescription = props => (
    <Stack horizontal verticalAlign="center">
      <span className={props.required ? "req" : ""}>{props.label}</span>
      <Icon iconName="Info" title="Info" ariaLabel="Info" />
    </Stack>
  );
  render() {
    const { showDialog, toggleDialog } = this.props;
    const {
      formFields: {
        collaborativeName,
        goal,
        selectedIndustry,
        context,
        storageLocation,
        format,
        terms
      },
      tcArray,
      filename
    } = this.state;
    return (
      <Modal
        isOpen={showDialog}
        isBlocking={false}
        containerClassName="container"
      >
        <div className="header">
          <div className="col-xs-11">Create Collaborative</div>
          <div className="col-xs-1 pull-right" style={{ textAlign: "right" }}>
            <Icon
              iconName="Cancel"
              className="ms-IconExample"
              onClick={toggleDialog}
            />
          </div>
        </div>
        <div className="row">
          <Pivot className="tabHeader">
            <PivotItem headerText="Collabrative Details">
              <div className="col-xs-12">
                The information will send to Collaborators you invite
              </div>
              <div className="col-xs-12">
                <TextField
                  label="Collaborative Name"
                  value={collaborativeName}
                  onChange={this.onChange}
                  required
                  placeholder="Ex. Cardiac Collaborative"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                />
              </div>
              <div className="col-xs-12">
                <div className="collab-field">
                  <div className="ms-TextField-wrapper">
                    <Stack horizontal verticalAlign="center">
                      <span className="req">Select Industry</span>
                      <Icon iconName="Info" title="Info" ariaLabel="Info" />
                    </Stack>
                    <ReactSuperSelect
                      placeholder="Select Industry"
                      onChange={() => {}}
                      dataSource={[
                        { value: "banana", name: "Banana" },
                        { value: "orange", name: "Orange" },
                        { value: "grape", name: "Grape" }
                      ]}
                    />
                  </div>
                </div>
              </div>
              <div className="col-xs-12">
                <TextField
                  label="Goal"
                  value={goal}
                  onChange={this.onChange}
                  required
                  placeholder="Why does this collaborative exist? What is end goal?"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                  multiline
                />
              </div>
              <div className="col-xs-12">
                <TextField
                  label="Data context"
                  value={context}
                  onChange={this.onChange}
                  required
                  placeholder="Ex. health records of children 18-24 with cardiac event"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                />
              </div>
              <div className="col-xs-12">
                <div className="col-xs-6">Collaborative Image</div>
                <div className="col-xs-6">
                  <div id="file-upload">
                    <div
                      className="fileinput fileinput-new"
                      data-provides="fileinput"
                      style={{ width: "400px", height: "40px" }}
                    >
                      <div
                        className="fileinput-new thumbnail"
                        style={{ width: "10%", height: "100%" }}
                      >
                        <img src={DummyImg} alt="..." />
                      </div>
                      <div
                        className="fileinput-preview fileinput-exists thumbnail"
                        style={{ maxWidth: "200px", maxHeight: "150px" }}
                      />
                      <div style={{ display: "inline-block" }}>
                        <span className="btn btn-default btn-file">
                          <span className="fileinput-new">Upload Image</span>
                          <span className="fileinput-exists">change</span>
                          <input type="file" accept="image/*" name="..." id="file1" onChange={(event) => {
                            console.log('asadf');
                            this.setState({
                              fileName: event.target.files[0].name
                            })
                          }} />
                        </span>
                        <a
                          href="#"
                          className="btn btn-default fileinput-exists"
                          data-dismiss="fileinput"
                        >
                          <Icon
                            iconName="Cancel"
                            className="ms-IconExample"
                          />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-xs-12">
                <TextField
                  label="Default Storage Location"
                  value={storageLocation}
                  onChange={this.onChange}
                  required
                  placeholder="Ex. Azure Location"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                />
              </div>
              <div className="col-xs-12">
                <div className="collab-field">
                  <div className="ms-TextField-wrapper">
                    <Stack horizontal verticalAlign="center">
                      <span className="req">Recommended Format</span>
                      <Icon iconName="Info" title="Info" ariaLabel="Info" />
                    </Stack>
                    <ReactSuperSelect
                      placeholder="Foramt"
                      onChange={() => {}}
                      dataSource={[
                        { value: "banana", name: "Banana" },
                        { value: "orange", name: "Orange" },
                        { value: "grape", name: "Grape" }
                      ]}
                    />
                  </div>
                </div>
              </div>
            </PivotItem>
            <PivotItem headerText="Terms of Use">
              <div className="col-xs-12">
                Upload Legal documents you would like all collaborators to
                accept or adhere by
              </div>
              {tcArray.map(d => (
                <div className="col-xs-12">
                  <div className="col-xs-3">{d.name}</div>
                  <div className="col-xs-9">
                    <div id="file-upload">
                      <div
                        className="fileinput fileinput-new"
                        data-provides="fileinput"
                      >
                        <div
                          className="fileinput-new thumbnail"
                          style={{ width: "200px", height: "100px" }}
                        >
                          <img src={DummyImg} alt="upload.." />
                        </div>
                        <div
                          className="fileinput-preview fileinput-exists thumbnail"
                          style={{ maxWidth: "200px", maxHeight: "30px" }}
                        />
                        <div>
                          <span className="btn btn-default btn-file">
                            <span className="fileinput-new">
                              Upload document
                            </span>
                            <span className="fileinput-exists">Change</span>
                            <input type="file" name="..." id={d.name} />
                          </span>
                          <a
                            href="#"
                            className="btn btn-default fileinput-exists"
                            data-dismiss="fileinput"
                          >
                            Remove
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div className="col-xs-12">
                <CommandBarButton
                  iconProps={{ iconName: "Add" }}
                  onClick={() => {
                    const name = window.prompt("Enter document name");
                    if (name != null) {
                      tcArray.push({ name });
                      this.setState({
                        tcArray
                      });
                    }
                  }}
                  text="Add More"
                />
              </div>
            </PivotItem>
          </Pivot>
        </div>
        <div>
          <DefaultButton text="Continue" />
        </div>
      </Modal>
    );
  }
}

export default AddCollab;
