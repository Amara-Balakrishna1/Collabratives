test('sum of 1 + 2 equals 3',() => {
  expect(1+2).toBe(3);
})