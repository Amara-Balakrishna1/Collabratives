import { all, fork, takeEvery, put, takeLatest, delay } from 'redux-saga/effects';


function* counterUp() {
    yield delay(3000);
    yield put({ type: 'COUNTER_UP_SAGA' });
}

function* counterDown() {
    yield put({ type: 'COUNTER_DOWN_SAGA' });
}

export function* watchCounterUp() {
    yield takeLatest('COUNTER_UP', counterUp);
}

export function* watchCounterDown() {
    yield takeEvery('COUNTER_DOWN', counterDown);
}

export default function* rootSaga() {
    yield all([
        fork(watchCounterUp),
        fork(watchCounterDown)
    ]);
}