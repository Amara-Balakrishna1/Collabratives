export function counterUp(): Object {
    return {
        type: "COUNTER_UP"
    }
}

export function counterDown(): Object {
    return {
        type: "COUNTER_DOWN"
    }
}