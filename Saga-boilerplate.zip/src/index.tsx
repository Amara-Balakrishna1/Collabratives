import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux'
import createSagaMiddlware from 'redux-saga';
import logger from 'redux-logger';
import reducer from './reducer';
import rootSaga from './saga';

import SagaCounter from './sagaCounter';

const sagaMiddlware = createSagaMiddlware();
const store = createStore(reducer, applyMiddleware(sagaMiddlware, logger));

sagaMiddlware.run(rootSaga);
function App(): JSX.Element {
    return <Provider store={store}>
        <SagaCounter />
    </Provider>;
}

ReactDOM.render(
    <App />,
    document.getElementById("root")
);
