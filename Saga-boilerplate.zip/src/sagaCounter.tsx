import * as React from 'react';
import { connect } from 'react-redux';
import { counterUp, counterDown } from './action';

function SagaCounter({count, counterDown, counterUp}) {
    return <table>
        <tbody>
            <tr><td>{count}</td></tr>
            <tr>
                <td><button onClick={() => counterDown()}>-</button></td>
                <td> <button onClick={() => counterUp()}>+</button></td>
            </tr></tbody>
    </table>;
}

function mapStateToProps(state: { count: { count: any; }; }) {
    return {
        count: state.count
    }
}

const mapDispatchToProps = (dispatch) => ({
    counterUp: () => dispatch(counterUp()),
    counterDown: () => dispatch(counterDown())
});
export default connect(mapStateToProps, mapDispatchToProps)(SagaCounter);