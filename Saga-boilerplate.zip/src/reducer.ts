const initialState = {
    count: 0
}

function appReducer(state = initialState, action) {
    switch (action.type) {
        case 'COUNTER_UP_SAGA': {
            return { ...state, count: state.count + 1 }
        }
        case 'COUNTER_DOWN_SAGA': {
            return { ...state, count: state.count - 1 }
        }
        default:
            return state
    }
}

export default appReducer;