import React, { Component } from "react";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { DefaultButton } from "office-ui-fabric-react/lib/Button";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { CommandBarButton } from "office-ui-fabric-react/lib/Button";
import ReactSuperSelect from "react-super-select";
import DummyImg from "../../images/Dummy_flag.png";
import Fileinput from "./Fileinput";
import "./modalStyle.scss";

// var file1 = $("#file1").val();

// $("#file-upload").on("change.bs.fileinput", function (e, file) {
//   //console.log(e)
//   $("#file1").val(file1);
// });

// $("#file-upload").on("clear.bs.fileinput", function (e, file) {
//   //console.log(e)
//   $("#file1").val(file1);
// });

class AddCollab extends Component {
  state = {
    formFields: {},
    tcArray: [
      {
        name: "Terms and Conditions"
      },
      {
        name: "Privacy Policy"
      }
    ]
  };
  onRenderDescription = props => (
    <Stack horizontal verticalAlign="center">
      <span className={props.required ? "req" : ""}>{props.label}</span>
      <Icon iconName="Info" title="Info" ariaLabel="Info" />
    </Stack>
  );
  render() {
    const { showDialog, toggleDialog } = this.props;
    const {
      formFields: {
        collaborativeName,
        goal,
        selectedIndustry,
        context,
        storageLocation,
        format,
        terms
      },
      tcArray,
      filename
    } = this.state;
    return (
      <Modal
        isOpen={showDialog}
        isBlocking={false}
        containerClassName="container"
      >
        <div className="header">
          <div className="col-xs-11">Create Collaborative</div>
          <div className="col-xs-1 pull-right" style={{ textAlign: "right" }}>
            <Icon
              iconName="Cancel"
              className="ms-IconExample"
              onClick={toggleDialog}
            />
          </div>
        </div>
        <div className="row">
          <Pivot className="tabHeader">
            <PivotItem headerText="Collabrative Details">
              <div className="col-xs-12">
                The information will send to Collaborators you invite
              </div>
              <div className="col-xs-12">
                <TextField
                  label="Collaborative Name"
                  value={collaborativeName}
                  onChange={this.onChange}
                  required
                  placeholder="Ex. Cardiac Collaborative"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                />
              </div>
              <div className="col-xs-12">
                <div className="collab-field">
                  <div className="ms-TextField-wrapper">
                    <Stack horizontal verticalAlign="center">
                      <span className="req">Select Industry</span>
                      <Icon iconName="Info" title="Info" ariaLabel="Info" />
                    </Stack>
                    <ReactSuperSelect
                      placeholder="Select Industry"
                      onChange={() => {}}
                      dataSource={[
                        { value: "banana", name: "Banana" },
                        { value: "orange", name: "Orange" },
                        { value: "grape", name: "Grape" }
                      ]}
                    />
                  </div>
                </div>
              </div>
              <div className="col-xs-12">
                <TextField
                  label="Goal"
                  value={goal}
                  onChange={this.onChange}
                  required
                  placeholder="Why does this collaborative exist? What is end goal?"
                  className="collab"
                  onRenderLabel={this.onRenderDescription}
                  multiline
                />
              </div>
              <div className="col-xs-12">
                <TextField
                  label="Data context"
                  value={context}
                  onChange={this.onChange}
                  required
                  placeholder="Ex. health records of children 18-24 with cardiac event"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                />
              </div>
              <div className="col-xs-12">
                <div className="collab-field">
                  <div className="ms-TextField-wrapper">
                    <div className="ms-Stack">Collaborative Image</div>
                    <div
                      className="ms-TextField-fieldGroup"
                      style={{ border: "none" }}
                    >
                      <Fileinput />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-xs-12">
                <TextField
                  label="Default Storage Location"
                  value={storageLocation}
                  onChange={this.onChange}
                  required
                  placeholder="Ex. Azure Location"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                />
              </div>
              <div className="col-xs-12">
                <div className="collab-field">
                  <div className="ms-TextField-wrapper">
                    <Stack horizontal verticalAlign="center">
                      <span className="req">Recommended Format</span>
                      <Icon iconName="Info" title="Info" ariaLabel="Info" />
                    </Stack>
                    <ReactSuperSelect
                      placeholder="Foramt"
                      onChange={() => {}}
                      dataSource={[
                        { value: "banana", name: "Banana" },
                        { value: "orange", name: "Orange" },
                        { value: "grape", name: "Grape" }
                      ]}
                    />
                  </div>
                </div>
              </div>
            </PivotItem>
            <PivotItem headerText="Terms of Use">
              <div className="col-xs-12">
                Upload Legal documents you would like all collaborators to
                accept or adhere by
              </div>
              {tcArray.map(d => (
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <div className="ms-Stack">Collaborative Image</div>
                      <div
                        className="ms-TextField-fieldGroup"
                        style={{ border: "none" }}
                      >
                        <Fileinput label="" id="" />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div className="col-xs-12">
                <CommandBarButton
                  iconProps={{ iconName: "Add" }}
                  onClick={() => {
                    const name = window.prompt("Enter document name");
                    if (name != null) {
                      tcArray.push({ name });
                      this.setState({
                        tcArray
                      });
                    }
                  }}
                  text="Add More"
                />
              </div>
            </PivotItem>
          </Pivot>
        </div>
        <div>
          <DefaultButton text="Continue" />
        </div>
      </Modal>
    );
  }
}

export default AddCollab;
