/* global $ */

import React, { Component } from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import DummyImg from "../../images/Dummy_flag.png";

class Fileinput extends Component {
  constructor(props) {
    super(props);
    this.textInput = React.createRef();
    this.state = {
      fileName: ''
    };
  }
  componentDidMount() {
    const that = this;
    $(this.textInput.current).on("change.bs.fileinput", function (e) {
      that.setState({
        fileName: (e.target.files[0] || {}).name
      });
    });
  }
  render() {
    const { fileName } = this.state;
    return (<div id="file-upload">
      <div
        className="fileinput fileinput-new"
        data-provides="fileinput"
        style={{ width: "400px", height: "40px" }}
      >
        <div
          className="fileinput-new thumbnail"
          style={{ width: "10%", height: "100%" }}
        >
          <img src={DummyImg} alt="..." />
        </div>
        <div
          className="fileinput-preview fileinput-exists thumbnail"
          style={{ maxWidth: "200px", maxHeight: "150px" }}
        />
        <div style={{ display: "inline-block" }}>
          <span className="btn btn-default btn-file">
            <span className="fileinput-new">Upload Image</span>
            <span className="fileinput-exists">{fileName}</span>
            {/* <span className="fileinput-exists">change</span> */}
            <input ref={this.textInput} type="file" accept="image/*" name="..." id="file1" onChange={(event) => {
              console.log('asadf');
              this.setState({
                fileName: event.target.files[0].name
              })
            }} />
          </span>
          <a
            href="javascript:void(0)"
            className="btn btn-default fileinput-exists"
            data-dismiss="fileinput"
          >
            <Icon
              iconName="Cancel"
              className="ms-IconExample"
            />
          </a>
        </div>
      </div>
    </div>
    )
  }
}

export default Fileinput;