import {
  GET_COLLABRATIVES,
  GET_COLLABRATIVEDETAILS
} from "../actions/collaborativesActions";

export default function visibilityFilter(state = {}, action) {
  switch (action.type) {
    case GET_COLLABRATIVES:
      return { ...state, collaboratives: action.data || [] };
    case GET_COLLABRATIVEDETAILS:
      return {
        ...state,
        collaborativeDetail: action.data
      };
    default:
      return state;
  }
}
