import {
  GET_COLLAborativeS,
  GET_COLLAborativeDETAILS,
  MANAGE_NOTIFICATION,
  UPDATE_DATASET
} from "../actions/collaborativesActions";

import { GET_RESOURCEGROUP, GET_INVITATIONS, GET_INVITATIONINFO } from "../actions/collaborativeInviteAction";

export default function visibilityFilter(state = {}, action) {
  switch (action.type) {
    case GET_COLLAborativeS: {
      const { data = [], industries = [], formats = [], subscriptions = [] } = action;
      return { ...state, collaboratives: data, industries, formats, subscriptions };
    }
    case GET_RESOURCEGROUP: {
      return { ...state, resourceGroupOptions: action.data };
    }
    case GET_COLLAborativeDETAILS:
      const { roles, statuses, subscriptions } = action;
      return {
        ...state,
        collaborativeDetail: action.data,
        collaborativeTerms: action.terms,
        organizations: action.organizations,
        members: action.members,
        roles,
        subscriptions,
        statuses
      };
    case GET_INVITATIONS: {
      return { ...state, invitations: action.data };
    }
    case GET_INVITATIONINFO: {
      return { ...state, invitationInfo: action.data };
    }
    case MANAGE_NOTIFICATION: {
      const { TimeLoader, displayMsg, notification } = action;
      return {
        ...state,
        TimeLoader,
        displayMsg,
        notification
      };
    }
    case UPDATE_DATASET: {
      const {  data } = action;
      const { collaborativeDetail } = state;
      return {
        ...state,
        collaborativeDetail: { ...collaborativeDetail, dataSets: data}
      }
    }
    default:
      return state;
  }
}
