import axios from "axios";
import config from "./config";
import urls from "./actionURLS";

import {
  onLoader,
  offLoader,
  errorTxt,
  success,
  getCollaborativeDetail
} from "./collaborativesActions";

export const GET_RESOURCEGROUP = "GET_RESOURCEGROUP";
export const GET_INVITATIONS = "GET_INVITATIONS";
export const GET_INVITATIONINFO = "GET_INVITATIONINFO";

export function inviteOrganization(collaborationId, data, component) {
  return dispatch => {
    dispatch(onLoader());
    axios
      .post(
        `${urls.commInvite}${collaborationId}/inviteorganization`,
        data,
        config
      )
      .then(result => {
        dispatch(offLoader(success, result.data));

        dispatch(getCollaborativeDetail(collaborationId));
        component.setState({
          showAMember: false,
          showIOrganization: false,
          showAddData: false
        });
      })
      .catch(err => {
        dispatch(offLoader(errorTxt, err.response.data.message));
      });
  };
}

export function inviteMember(collaborationId, data, component) {
  return dispatch => {
    dispatch(onLoader());
    axios
      .post(`${urls.commInvite}${collaborationId}/invitemember`, data, config)
      .then(result => {
        dispatch(offLoader(success, result.data));
        dispatch(getCollaborativeDetail(collaborationId));
        component.setState({
          showAMember: false,
          showIOrganization: false,
          showAddData: false
        });
      })
      .catch(err => {
        dispatch(offLoader(errorTxt, err.response.data.message));
      });
  };
}

export function getResourceGroup(subsId) {
  return dispatch => {
    axios
      .get(`${urls.userURL}/subscriptions/${subsId}/resourcegroups`, config)
      .then(result => {
        dispatch({
          type: GET_RESOURCEGROUP,
          data: result.data
        });
      });
  };
}

export function getInvitations() {
  return dispatch => {
    axios.get(`${urls.userURL}/invitations`, config).then(result => {
      dispatch({
        type: GET_INVITATIONS,
        data: result.data
      });
    });
  };
}

export function getInvitationInfo(collaborationId) {
  return dispatch => {
    axios
      .get(`${urls.userURL}/invitations/${collaborationId}`, config)
      .then(result => {
        dispatch({
          type: GET_INVITATIONINFO,
          data: result.data
        });
      });
  };
}

export function joinMember(collaborationId) {
  const data = {
    memberStatus: "Accepted"
  };

  return dispatch => {
    dispatch(onLoader());
    axios
      .post(`${urls.userURL}/collaborations/${collaborationId}/join`, data, config)
      .then(result => {
        dispatch(getInvitations());
        dispatch(offLoader(success, result.data));
      })
      .catch(err => {
        dispatch(offLoader(errorTxt, err.response.data.message));
      });
  };
}
