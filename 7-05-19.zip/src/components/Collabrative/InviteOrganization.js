import React, { Component } from "react";
import { Label } from "office-ui-fabric-react/lib/Label";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton, Dropdown } from "office-ui-fabric-react";
import { Stack } from "office-ui-fabric-react/lib/Stack";
// import { Link } from "react-router-dom";
// import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Checkbox } from "office-ui-fabric-react/lib/Checkbox";
import {
  CommandBarButton,
  DefaultButton
} from "office-ui-fabric-react/lib/Button";
import {
  Persona,
  PersonaSize
  // PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
import Wrapper from "./Addwrapper";
import Fileinput from "../Collaboratives/Fileinput";
import "./InviteOrganization.scss";

class InviteOrganization extends Component {
  constructor(props) {
    super(props);
    this.state = {
      organizationsList: props.organizations,
      formFields: {
        // organizationName: "",
        // newOrg: "",
        // adminName: "",
        adminEmail: ""
      },
      tcArray: props.collaborativeTerms,
      // tcArray: [
      //   {
      //     documentName: "Terms and Conditions",
      //     fileName: "T & C.pdf"
      //   },
      //   {
      //     documentName: "Privacy Policy",
      //     fileName: "Privacy.pdf"
      //   }
      // ],
      newFields: [],
      options: [
        { key: "appolo", text: "Appolo" },
        { key: "lvprasad", text: "L V Prasad" },
        { key: "bascam", text: "Bascam Palmer" }
      ]
    };
  }
  // componentDidMount() {
  //   this.props.getOrganizations();
  // }
  onChange = (field, value) => {
    const { formFields } = this.state;

    // const result = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    // if (field === "adminEmail" && !result) {
    // } else {
    formFields[field] = value;
    // }
    this.setState({
      formFields
    });
  };
  fileChange = (root, index, data, name) => {
    const subData = this.state[root];
    subData[index].documentUrl = data;
    subData[index].documentDisplayName = name;
    this.setState({
      [root]: subData
    });
  };
  setTCName = (index, data) => {
    const subData = this.state.newFields;
    subData[index].documentName = data;
    this.setState({
      newFields: subData
    });
  };
  render() {
    const { toggleData, inviteOrganization } = this.props;
    const {
      tcArray,
      newFields,
      formFields,
      options,
      organizationsList
    } = this.state;
    const { organizationName, adminEmail, adminName, newOrg } = formFields;
    const organizations = [...options, { key: "others", text: "others" }];
    return (
      <Wrapper toggleData={toggleData} name="showIOrganization">
        <div
          className="row IO"
          style={{
            height: "90%",
            padding: "20px",
            margin: "0px",
            overflow: "auto"
          }}
        >
          <Label>Invite Organization</Label>
          {/* <Dropdown
            label="Select Organization"
            options={organizations}
            // selectedKey={}
            onChange={(ev, value) =>
              this.onChange("organizationName", value.key)
            }
          />
          {organizationName === "others" && (
            <TextField
              label="Organization Name"
              value={newOrg}
              onChange={(ev, value) => this.onChange("newOrg", value)}
              placeholder="Ex. John"
              className="collab-field"
              styles={{ padding: "5px" }}
            />
          )}
          <TextField
            label="Organization Admin Name"
            value={adminName}
            onChange={(ev, value) => this.onChange("adminName", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          /> */}
          <TextField
            type="email"
            label="Organization Admin Email"
            value={adminEmail}
            onChange={(ev, value) => this.onChange("adminEmail", value)}
            placeholder="Ex. John@abc.com"
            className="collab-field"
            // errorMessage="Error message"
            styles={{ padding: "5px" }}
          />
          <Label>Collaborative Legal Document</Label>
          {tcArray.map((d, i) => (
            <div
              key={`${parseInt(Math.random() * 1000)}-12`}
              className="row io-root"
            >
              <div className="collab-field">
                <div className="ms-TextField-wrapper">
                  {/* <div className="ms-Stack">{d.name}</div> */}

                  <Stack horizontal verticalAlign="center">
                    <Checkbox
                      disabled
                      defaultChecked={true}
                      onChange={() => {}}
                    />
                    <span>{d.policyName}</span>
                  </Stack>
                  <a target="_blank" href={d.documentUrl}>
                    <TextField readOnly value={d.documentName} />
                  </a>
                </div>
              </div>
            </div>
          ))}
          <div className="row" style={{ padding: "20px 10px" }}>
            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              style={{ background: "none", color: "#0078D4" }}
              onClick={() => {
                newFields.push({});
                this.setState({
                  newFields
                });
              }}
              text="Add additional organization specific documents"
            />
          </div>
          {newFields.length ? (
            <div className="newFields">
              {newFields.map((d, i) => (
                <div className="row moreField">
                  <div className="collab-field">
                    <TextField
                      value={d.documentName}
                      onChange={(ev, value) => {
                        this.setTCName(i, value);
                      }}
                      // required
                      placeholder="Ex. Label"
                    />
                    <Fileinput
                      root="newFields"
                      label={d.documentName}
                      // url={d.documentUrl}
                      id={`nf-${i}`}
                      index={i}
                      fileChange={this.fileChange}
                    />
                    <DefaultButton
                      className="pull-right removeButton"
                      // iconProps={{ iconName: "Add" }}
                      style={{ background: "none", color: "#0078D4" }}
                      onClick={() => {
                        newFields.splice(i, 1);
                        this.setState({
                          newFields
                        });
                      }}
                      text="remove"
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : null}
          <hr />
          <div
            className="row"
            style={{ height: "40%", padding: "20px", margin: "0px" }}
          >
            <Label className="heading">Organizations</Label>
            <div className="row organizations">
              <table>
                <thead>
                  <tr>
                    <td>Organization</td>
                    <td>Status</td>
                  </tr>
                </thead>
                <tbody>
                  {organizationsList.map((d, i) => (
                    <tr>
                      <td>
                        <Persona
                          imageUrl={d.organizationLogo}
                          text={d.organizationName}
                          imageInitials=""
                          size={PersonaSize.size28}
                        />
                      </td>
                      <td>{d.organizationStatus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="row" style={{ padding: "20px", margin: "0px" }}>
          <PrimaryButton
            text="Invite Organization"
            onClick={() => {
              const {
                tcArray,
                newFields,
                formFields: { adminEmail }
              } = this.state;
              const payload = {
                memberEmailId: adminEmail,
                termsOfUses: [
                  // ...tcArray,
                  ...newFields.map(d => ({
                    policyName: d.documentName,
                    documentName: d.documentDisplayName,
                    documentUrl: d.documentUrl
                  }))
                ]
              };
              console.log(payload);
              inviteOrganization(payload);
            }}
          />
        </div>
      </Wrapper>
    );
  }
}

export default InviteOrganization;
