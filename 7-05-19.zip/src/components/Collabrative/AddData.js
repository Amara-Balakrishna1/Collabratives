import React, { Component } from "react";
import {
  Pivot,
  PivotItem,
  // PivotLinkFormat,
  PivotLinkSize
} from "office-ui-fabric-react/lib/Pivot";
import { Toggle } from "office-ui-fabric-react/lib/Toggle";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Label } from "office-ui-fabric-react/lib/Label";
import { Callout, DirectionalHint } from "office-ui-fabric-react/lib/Callout";
import { Calendar, DayOfWeek } from "office-ui-fabric-react/lib/Calendar";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { Dropdown } from "office-ui-fabric-react/lib/Dropdown";
import { FocusTrapZone } from "office-ui-fabric-react/lib/FocusTrapZone";
import {
  CommandBarButton,
  // DefaultButton,
  PrimaryButton
} from "office-ui-fabric-react/lib/Button";
import moment from "moment";
import Wrapper from "./Addwrapper";
import "./addData.scss";

const DayPickerStrings = {
  months: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ],
  shortMonths: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  days: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ],
  shortDays: ["S", "M", "T", "W", "T", "F", "S"],
  goToToday: "Go to today",
  weekNumberFormatString: "Week number {0}",
  prevMonthAriaLabel: "Previous month",
  nextMonthAriaLabel: "Next month",
  prevYearAriaLabel: "Previous year",
  nextYearAriaLabel: "Next year",
  prevYearRangeAriaLabel: "Previous year range",
  nextYearRangeAriaLabel: "Next year range",
  closeButtonAriaLabel: "Close"
};
// const storageResourceGroups = ["collaboratives-testing01"];
class AddData extends Component {
  constructor(props) {
    super(props);
    var someDate = new Date();
    var numberOfDaysToAdd = 6;
    someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
    this.state = {
      formFields: {
        isAutoSync: true,
        c1value: new Date(),
        c2value: someDate
      },
      storageContainerUrls: [""],
      subscriptionIds: props.subscriptions.map(d => ({
        key: d.subscriptionId,
        text: d.resourceName
      }))
    };
    this.Calendar1 = React.createRef();
    this.Calendar2 = React.createRef();
  }
  static getDerivedStateFromProps(nextProps) {
    return {
      storageResourceGroups: nextProps.resourceGroupOptions
    };
  }
  onChange = (field, value) => {
    const { formFields } = this.state;
    formFields[field] = value;
    this.setState({
      formFields
    });
  };
  toggleCallout(calander) {
    this.setState({
      [calander]: !this.state[calander]
    });
  }
  onSelectDate(cfield, date, calander) {
    const { formFields } = this.state;
    formFields[cfield] = date;
    this.setState(
      {
        formFields
      },
      () => {
        this.toggleCallout(calander);
      }
    );
  }
  render() {
    const {
      calander1,
      calander2,
      formFields = {},
      storageContainerUrls = [],
      activeTab,
      subscriptionIds,
      storageResourceGroups = []
    } = this.state;
    const {
      dataSetName,
      c2value,
      c1value,
      subscriptionId,
      storageResourceGroup,
      description,
      isAutoSync
    } = formFields;
    const dataStartDate = moment(c1value).format("YYYY-MM-DD");
    const dataEndDate = moment(c2value).format("YYYY-MM-DD");
    const { toggleData, postData, collaborationId } = this.props;
    return (
      <Wrapper toggleData={toggleData} name="showAddData">
        <Pivot
          className="tabHeader"
          // linkFormat={PivotLinkFormat.tabs}
          linkSize={PivotLinkSize.large}
          selectedKey={activeTab}
        >
          <PivotItem
            itemKey="Tab1"
            className="tabContent"
            itemIcon={activeTab ? "StatusCircleCheckmark" : ""}
            headerText="Select Data"
          >
            <div style={{ height: "100%" }} className="col-xs-12">
              {/* <TextField
                label="Subscription"
                value={subscriptionId}
                onChange={(ev, value) => this.onChange("subscriptionId", value)}
                placeholder="Ex. e0d6ce1f-8f81-42ed-854d-05eb1bd41c6b"
                className="collab-field"
                styles={{ padding: "5px" }}
              /> */}

              <div className="collab-field">
                <div className="ms-TextField-wrapper">
                  <Stack
                    horizontal
                    verticalAlign="center"
                    style={{ padding: "5px 0px" }}
                  >
                    <span className="ms-Label">Subscription</span>
                  </Stack>
                  <Dropdown
                    // selectedKey={subscriptionId}
                    placeholder={`Ex. ${subscriptionIds[0].text}`}
                    onChange={(ev, value) => {
                      this.props.getResourceGroup(value.key);
                      this.onChange("subscriptionId", value.key);
                    }}
                    // onRenderTitle={this.onRenderDescription}
                    options={subscriptionIds}
                  />
                </div>
              </div>

              {/* <TextField
                label="Resource Group"
                value={storageResourceGroup}
                onChange={(ev, value) =>
                  this.onChange("storageResourceGroup", value)
                }
                placeholder="Ex. Testing"
                className="collab-field"
                styles={{ padding: "5px" }}
              /> */}
              <div className="collab-field">
                <div className="ms-TextField-wrapper">
                  <Stack
                    horizontal
                    verticalAlign="center"
                    style={{ padding: "5px 0px" }}
                  >
                    <span className="ms-Label">Resource Group</span>
                  </Stack>
                  <Dropdown
                    selectedKey={storageResourceGroup}
                    placeholder="Ex. Testing"
                    onChange={(ev, value) => {
                      this.onChange("storageResourceGroup", value.key);
                    }}
                    // onRenderTitle={this.onRenderDescription}
                    options={storageResourceGroups.map(d => ({
                      key: d,
                      text: d
                    }))}
                  />
                </div>
              </div>
              <hr />
              {storageContainerUrls.map((d, i) => (
                <div className="urls-Textbox">
                  <TextField
                    label=" "
                    value={d}
                    onChange={(ev, value) => {
                      const { storageContainerUrls } = this.state;
                      storageContainerUrls[i] = value;
                      this.setState({
                        storageContainerUrls
                      });
                    }}
                    placeholder="Ex. collaborativesprovider01/refractive-data-v1"
                    className="collab-field"
                    styles={{ padding: "5px" }}
                  />
                  {i ? (
                    <Icon
                      style={{ fontSize: "16px" }}
                      iconName="Cancel"
                      className="ms-IconExample"
                      onClick={(i) => {
                        const { storageContainerUrls = [] } = this.state;
                        const data = [... storageContainerUrls]
                         data.splice(i, 1)
                        this.setState({
                          storageContainerUrls: data
                        });
                      }}
                    />
                  ) : null}
                </div>
              ))}
              <CommandBarButton
                iconProps={{ iconName: "Add" }}
                onClick={() => {
                  const { storageContainerUrls } = this.state;
                  storageContainerUrls.push("");
                  this.setState({
                    storageContainerUrls
                  });
                }}
                style={{ padding: "8px 4px", margin: "10px 0px" }}
                text="Add Container"
              />
            </div>

            <PrimaryButton
              className="pull-right"
              text="Add"
              onClick={() => {
                this.setState({
                  activeTab: "Tab2"
                });
              }}
            />
          </PivotItem>
          <PivotItem
            className="tabContent"
            headerText="Description"
            itemKey="Tab2"
          >
            <div style={{ height: "100%" }}>
              <TextField
                label="Name the data set"
                value={dataSetName}
                onChange={(ev, value) => this.onChange("dataSetName", value)}
                placeholder="Ex. Refractive Error Data V1"
                className="collab-field"
                style={{ padding: "15px 0px" }}
              />
              <Label className="comm-margin">Describe the data set</Label>
              <label className="ms-Label">
                Time Frame <span>(Optional)</span>
              </label>
              <div className="col-xs-12 comm-margin" style={{ padding: "0px" }}>
                <div
                  ref={this.Calendar1}
                  onClick={() => {
                    this.toggleCallout("calander1");
                  }}
                  className="col-xs-6"
                  style={{ padding: "0px" }}
                >
                  <div className="input-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Username"
                      value={dataStartDate}
                      onChange={() => {}}
                    />
                    <span className="icon-pos">
                      <Icon
                        style={{ fontSize: "16px" }}
                        iconName="Calendar"
                        className="ms-IconExample"
                      />
                    </span>
                  </div>
                </div>
                <div
                  onClick={() => {
                    this.toggleCallout("calander2");
                  }}
                  ref={this.Calendar2}
                  className="col-xs-6"
                  style={{ padding: "0px" }}
                >
                  <div className="input-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Username"
                      onChange={() => {}}
                      value={dataEndDate}
                    />
                    <span className="icon-pos">
                      <Icon
                        style={{ fontSize: "16px" }}
                        iconName="Calendar"
                        className="ms-IconExample"
                      />
                    </span>
                  </div>
                </div>
              </div>
              {calander1 && (
                <Callout
                  isBeakVisible={false}
                  className="ms-DatePicker-callout"
                  gapSpace={0}
                  doNotLayer={false}
                  target={this.Calendar1.current}
                  directionalHint={DirectionalHint.bottomLeftEdge}
                  onDismiss={this._onDismiss}
                  setInitialFocus={true}
                >
                  <FocusTrapZone isClickableOutsideFocusTrap={true}>
                    <Calendar
                      onSelectDate={date => {
                        this.onSelectDate("c1value", date, "calander1");
                      }}
                      isMonthPickerVisible
                      value={c1value}
                      firstDayOfWeek={DayOfWeek.Sunday}
                      strings={DayPickerStrings}
                      isDayPickerVisible
                      highlightCurrentMonth
                      highlightSelectedMonth
                      showMonthPickerAsOverlay
                      showGoToToday
                    />
                  </FocusTrapZone>
                </Callout>
              )}
              {calander2 && (
                <Callout
                  isBeakVisible={false}
                  className="ms-DatePicker-callout"
                  gapSpace={0}
                  doNotLayer={false}
                  target={this.Calendar2.current}
                  directionalHint={DirectionalHint.bottomLeftEdge}
                  onDismiss={this._onDismiss}
                  setInitialFocus={true}
                >
                  <FocusTrapZone isClickableOutsideFocusTrap={true}>
                    <Calendar
                      onSelectDate={date => {
                        this.onSelectDate("c2value", date, "calander2");
                      }}
                      isMonthPickerVisible
                      value={c2value}
                      firstDayOfWeek={DayOfWeek.Sunday}
                      strings={DayPickerStrings}
                      isDayPickerVisible
                      highlightCurrentMonth
                      highlightSelectedMonth
                      showMonthPickerAsOverlay
                      showGoToToday
                      minDate={c1value}
                    />
                  </FocusTrapZone>
                </Callout>
              )}
              <TextField
                label="Description"
                multiline
                rows={3}
                value={description}
                onChange={(ev, value) => this.onChange("description", value)}
                placeholder="Briefly describe the data set"
              />
              {/* <Toggle
                defaultChecked
                className="comm-margin"
                onChange={(ev, checked) => this.onChange("isAutoSync", checked)}
                inlineLabel
                label="Auto Sync"
                checked={isAutoSync}
              /> */}
            </div>
            <PrimaryButton
              text="Back"
              onClick={() => {
                this.setState({
                  activeTab: "Tab1"
                });
              }}
            />
            <PrimaryButton
              className="pull-right"
              text="Add Data"
              onClick={() => {
                const { storageContainerUrls, formFields } = this.state;
                // const {
                //   dataSetName,
                //   description,
                //   isAutoSync,
                //   subscriptionId,
                //   storageResourceGroup
                // } = formFields;
                const data = {
                  ...formFields,
                  storageContainerUrls,
                  dataStartDate,
                  dataEndDate
                };
                // console.log(data);
                postData(collaborationId, data);
              }}
            />
          </PivotItem>
        </Pivot>
      </Wrapper>
    );
  }
}
export default AddData;
