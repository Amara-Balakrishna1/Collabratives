import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import {
  CommandBarButton,
  DefaultButton
} from "office-ui-fabric-react/lib/Button";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  Persona,
  PersonaSize
  // PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
// import { List } from "office-ui-fabric-react/lib/List";
import { Link } from "react-router-dom";
import {
  DetailsList,
  DetailsRow,
  DetailsListLayoutMode,
  SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
// import { Callout } from "office-ui-fabric-react/lib/Callout";
// import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { mergeStyleSets } from "office-ui-fabric-react/lib/Styling";

import {
  Adddata,
  InviteOrganization,
  AddMembers
} from "../components/Collabrative";
import {
  getCollaborativeDetail,
  postData,
  importDataSet
} from "../actions/collaborativesActions";
import {
  inviteOrganization,
  inviteMember,
  getResourceGroup
} from "../actions/collaborativeInviteAction";
import "./CollaborativeContainer.scss";

// const uuidv1 = require("uuid/v1");s

const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: "16px"
  },
  fileIconCell: {
    textAlign: "center",
    selectors: {
      "&:before": {
        content: ".",
        display: "inline-block",
        verticalAlign: "middle",
        height: "100%",
        width: "0px",
        visibility: "hidden"
      }
    }
  },
  fileIconImg: {
    verticalAlign: "middle",
    maxHeight: "16px",
    maxWidth: "16px"
  },
  controlWrapper: {
    display: "flex",
    flexWrap: "wrap"
  },
  exampleToggle: {
    display: "inline-block",
    marginBottom: "10px",
    marginRight: "30px"
  },
  selectionDetails: {
    marginBottom: "20px"
  }
});
// const controlStyles = {
//   root: {
//     margin: '0 30px 20px 0',
//     maxWidth: '300px'
//   }
// };

// const examplePersona = {
//   // imageUrl: TestImages.personaFemale,
//   imageInitials: "AL",
//   text: "Annie Lindqvist",
//   secondaryText: "Software Engineer",
//   tertiaryText: "In a meeting",
//   optionalText: "Available at 4:00pm"
// };

class Collaborative extends Component {
  constructor(props) {
    super(props);
    const that = this;
    const { collaborationId } = props.match.params;
    that.t2 = React.createRef();
    const columns = [
      {
        key: "column1",
        name: "File Type",
        className: classNames.fileIconCell,
        iconClassName: classNames.fileIconHeaderIcon,
        ariaLabel:
          "Column operations for File type, Press to sort on File type",
        iconName: "Page",
        isIconOnly: true,
        fieldName: "name",
        minWidth: 16,
        maxWidth: 16,
        onRender: item => (
          <div>
            <Icon
              style={{ fontSize: "16px" }}
              iconName={
                item.status === "Pending" ? "RepeatAll" : "FabricFolderFill"
              }
              className="ms-IconExample"
            />
          </div>
        )
      },
      {
        key: "column2",
        name: "Data Set Name",
        fieldName: "name",
        minWidth: 110,
        maxWidth: 130,
        isRowHeader: true,
        isResizable: true,
        isSorted: true,
        isSortedDescending: false,
        sortAscendingAriaLabel: "Sorted A to Z",
        sortDescendingAriaLabel: "Sorted Z to A",
        // onRender: item => <span>{that.getName(item.storageAccountName)}</span>,

        data: "string",
        isPadded: true
      },
      {
        key: "column3",
        name: "Description",
        fieldName: "dateModifiedValue",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        data: "number",
        onRender: (item, index) => {
          return (
            <Icon
              iconName="Info"
              className="ms-IconExample"
              // ref={this[`t${index}`]}
              onMouseOver={event => {
                that.setState({
                  isCalloutVisible: true,
                  callDescription: `${item.description}${index}`,
                  callFrame: `${moment(item.dataStartDate).format(
                    "MMM-YYYY"
                  )}-${moment(item.dataEndDate).format("MMM-YYYY")}`,
                  top: event.clientY - 125,
                  left: event.clientX - 155
                });
              }}
              onMouseLeave={() => {
                this.setState({
                  isCalloutVisible: false
                });
              }}
            />
          );
        },
        isPadded: true
      },
      {
        key: "column4",
        name: "Shared By",
        fieldName: "modifiedBy",
        minWidth: 150,
        maxWidth: 180,
        isResizable: true,
        isCollapsible: true,
        data: "string",
        onRender: item => <span>{that.getName(item.ownerId)}</span>,
        isPadded: true
      },
      {
        key: "column5",
        name: "Size",
        fieldName: "fileSizeRaw",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => <span>{item.sizeInGB}</span>
      },
      {
        key: "column6",
        name: "Last Modified",
        fieldName: "fileSizeRaw",
        minWidth: 160,
        maxWidth: 180,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <span>
            {moment(item.lastModified).format("ddd DD-MMM-YYYY hh:mm A")}
          </span>
        )
      },
      // {
      //   key: "column13",
      //   name: "Location",
      //   // className: classNames.fileIconCell,
      //   // iconClassName: classNames.fileIconHeaderIcon,
      //   // ariaLabel:
      //   //   "Column operations for File type, Press to sort on File type",
      //   // iconName: "Page",
      //   // isIconOnly: true,
      //   fieldName: "name",
      //   minWidth: 120,
      //   maxWidth: 160,
      //   onRender: item => (
      //     <Link to="/subscriptions/b2251f1c-ceaa-4">
      //       /subscriptions/b2251f1c-ceaa-4
      //     </Link>
      //   )
      // },
      {
        key: "column7",
        name: "Status",
        fieldName: "fileSizeRaw",
        minWidth: 150,
        maxWidth: 180,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <>
            {item.isAvailableToImport ? (
              <DefaultButton
                text="Import"
                style={{ width: "125px", marginBottom: 10 }}
                onClick={() => {
                  that.props.importDataSet(collaborationId, item);
                }}
              />
            ) : (
              <DefaultButton
                className="column"
                text={item.status}
                style={{ width: "125px" }}
              />
            )}
            <Icon
              style={{ fontSize: "16px", marginTop: 5 }}
              iconName="MoreVertical"
              className="ms-IconExample"
              onClick={event => {
                console.log("a");
                const { nativeEvent } = event;
                this.setState({
                  isStatusCalloutVisible: true,
                  statusTop: nativeEvent.clientY - 125,
                  statusLeft: nativeEvent.clientX - 155
                });
              }}
            />
          </>
        )
      }
      // {
      //   key: "column11",
      //   name: "File Type",
      //   className: classNames.fileIconCell,
      //   iconClassName: classNames.fileIconHeaderIcon,
      //   ariaLabel:
      //     "Column operations for File type, Press to sort on File type",
      //   iconName: "Page",
      //   isIconOnly: true,
      //   fieldName: "name",
      //   minWidth: 16,
      //   maxWidth: 16,
      //   onRender: item => (
      //     <div>
      //       <Icon
      //         style={{ fontSize: "16px" }}
      //         iconName="MoreVertical"
      //         className="ms-IconExample"
      //       />
      //     </div>
      //   )
      // }
    ];
    // const user = "5F304F82-1A81-459C-80B1-89D107FC9262"; //"8a2905e6-03a3-4027-82ae-ed0b8bce69b8" //normal user
    // const admin = "810917c0-9083-4afa-b783-caa9010dc806"; // admin

    // const r = window.confirm("Choose the user");
    // if (r == true) {
    //   sessionStorage.setItem("userID", admin);
    // } else {
    //   sessionStorage.setItem("userID", user);
    // }
    this.state = {
      collaborationId,
      columns
    };
  }
  componentDidMount() {
    const { getCollaborativeDetail } = this.props;
    const { collaborationId } = this.state;
    getCollaborativeDetail(collaborationId);
  }
  static getDerivedStateFromProps(nextProps) {
    const { activityLog = [], dataSets = [] } = Object(
      nextProps.collaborativeDetail
    );
    return {
      items: dataSets || [],
      activityLog
    };
  }
  onRenderRow = props => {
    return (
      <DetailsRow
        {...props}
        styles={{
          root: {
            backgroundColor: props.item.status !== "Imported" ? "#FFF4CE" : ""
          }
        }}
      />
    );
  };
  getName = (id, log) => {
    const { collaborators = [] } = this.props.collaborativeDetail;
    const obj = collaborators.filter(d => d.id === id)[0] || {};
    if (log) {
      return `${obj.organizationName}(${obj.fullName})` || "";
    }
    return `${obj.fullName}(${obj.emailId})` || "";
  };
  getInitials(name = "") {
    const arr = name ? name.split(".") : [[], []];
    return `${(arr[0][0] || "").toUpperCase()}${(
      arr[1][0] || ""
    ).toUpperCase()}`;
  }
  toggleNav = tabName => {
    this.setState({
      [tabName]: !this.state[tabName]
    });
  };
  postDataSet = (collaborationId, data) => {
    // const { collaborationId } = this.state;
    this.props.postData(collaborationId, data, this);
  };
  inviteOrganization = data => {
    const { collaborationId } = this.state;
    this.props.inviteOrganization(collaborationId, data, this);
  };
  inviteMember = data => {
    const { collaborationId } = this.state;
    this.props.inviteMember(collaborationId, data, this);
  };
  render() {
    const {
      columns,
      isCompactMode,
      items,
      isModalSelection,
      activityLog,
      isCalloutVisible,
      isStatusCalloutVisible,
      callDescription,
      callFrame,
      top,
      left,
      statusLeft,
      statusTop,
      showAddData,
      showAMember,
      showIOrganization,
      collaborationId
    } = this.state;
    const {
      collaborativeDetail,
      collaborativeTerms,
      organizations = [],
      members,
      roles,
      subscriptions,
      getResourceGroup,
      resourceGroupOptions
    } = this.props;
    const { collaborators = [], information = {}, isAdmin } = Object(
      collaborativeDetail
    );
    const admin =
      collaborators.filter(d => d.userRole === "CollaborativeAdmin")[0] || {};
    const nonAdmin = collaborators.filter(
      d => d.userRole !== "CollaborativeAdmin"
    );
    const showRightNav = showAddData || showAMember || showIOrganization;
    return (
      <div className="detail-collabarative">
        <div className="col-xs-12 addRow">
          <div className="col-xs-11">
            {isCalloutVisible && (
              <div
                className="ms-CalloutExample-callout"
                style={{
                  zIndex: 99,
                  position: "fixed",
                  top,
                  left
                }}
              >
                <div>{callDescription}</div>
                <div>
                  <b>Time Frame: </b>
                  {callFrame}
                </div>
              </div>
            )}
            {isStatusCalloutVisible && (
              <div
                className="ms-CalloutExample-callout"
                style={{
                  zIndex: 99,
                  position: "fixed",
                  top: statusTop,
                  left: statusLeft
                }}
              >
                <div>{callDescription}</div>
                <div>
                  <b>Time Frame: </b>
                  {callFrame}
                </div>
              </div>
            )}

            {isAdmin ? null : (
              <CommandBarButton
                iconProps={{ iconName: "CloudUpload" }}
                onClick={() => {
                  this.setState({
                    showAddData: true,
                    showIOrganization: false,
                    showAMember: false
                  });
                }}
                text="Add Data"
              />
            )}
            {isAdmin ? (
              <CommandBarButton
                iconProps={{ iconName: "CityNext2" }}
                onClick={() => {
                  this.setState({
                    showIOrganization: true,
                    showAddData: false,
                    showAMember: false
                  });
                }}
                text="Invite Organization"
              />
            ) : null}
            {isAdmin ? (
              <CommandBarButton
                iconProps={{ iconName: "PeopleAdd" }}
                onClick={() => {
                  this.setState({
                    showAMember: true,
                    showIOrganization: false,
                    showAddData: false
                  });
                }}
                text="Add Members"
              />
            ) : null}
          </div>
          {/* <div className="col-xs-1">
            <Icon iconName="Info" className="ms-IconExample" />
          </div> */}
        </div>
        <div className="col-xs-12 collabInfo">
          <div className="col-xs-7 center-content">
            <Persona
              imageUrl={information.imageUrl}
              text={information.name}
              secondaryText={information.defaultAzureStorageLocation}
              size={PersonaSize.size72}
              onRenderPrimaryText={data => (
                <div style={{ fontSize: "24px" }}>
                  <span>{data.text} </span>
                  <a style={{ fontSize: "14px" }} href="javascript:void(0)">
                    {" "}
                    View Detail
                  </a>
                </div>
              )}
              onRenderSecondaryText={data => (
                <div>
                  <b>Default Location: </b>
                  {(data.secondaryText || "").substring(0, 30)}...
                  <CommandBarButton
                    className="detail-persona"
                    iconProps={{ iconName: "Edit" }}
                    onClick={() => {
                      console.log("adfasd");
                    }}
                    text="Edit"
                  />
                </div>
              )}
            />
          </div>
          <div className="col-xs-5 ">
            <div className="persons">
              <div className="col-xs-3">Admin:</div>
              <div className="col-xs-9">
                <Persona
                  text={
                    admin.fullName
                      ? `${admin.organizationName} (${admin.fullName})`
                      : ""
                  }
                  size={PersonaSize.size32}
                  imageUrl={
                    Object(
                      organizations.find(
                        d => d.organizationName === admin.organizationName
                      )
                    ).organizationLogo
                  }
                  // imageInitials={this.getInitials(admin.userName)}
                />
              </div>
            </div>
            <div className="persons">
              <div className="col-xs-3">
                Collaborators({organizations.length}):
              </div>
              <div className="col-xs-9 persona-list">
                {organizations.map(item => (
                  <Persona
                    key={`${item.userName ||
                      parseInt(Math.random() * 1000)}-12`}
                    // {...item}
                    size={PersonaSize.size32}
                    title={item.organizationName}
                    imageUrl={item.organizationLogo}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="col-xs-12 dataInfo">
          <div className="col-xs-9 data-container">
            <div className="col-xs-12 data">
              <div className="col-xs-4">
                <div className="center-text">
                  <div className="storage-details hardcode">0</div>
                  <div className="storage-label">GB of Data</div>
                </div>
              </div>
              <div className="col-xs-4">
                <div className="center-text">
                  <div className="storage-details">{nonAdmin.length}</div>
                  <div className="storage-label">Members</div>
                </div>
              </div>
              {/* <div className="col-xs-3">
                <div className="storage-details" >&nbsp;</div>
                <div className="storage-label">
                  Volume Trends
                </div>
              </div> */}
              <div className="col-xs-4">
                <div className="center-text">
                  <div className="storage-details hardcode">0</div>
                  <div className="storage-label">Models</div>
                </div>
              </div>
            </div>
            <div
              className="col-xs-12"
              style={{
                fontFamily: "Segoe UI",
                fontSize: "20px",
                height: "52px",
                padding: "0px 10px"
              }}
            >
              Collaborative Data
            </div>
            <div className="col-xs-12 dataList">
              <DetailsList
                items={items}
                compact={isCompactMode}
                columns={columns}
                selectionMode={
                  isModalSelection ? SelectionMode.multiple : SelectionMode.none
                }
                // onRenderRow={this.onRenderRow}
                setKey="set"
                layoutMode={DetailsListLayoutMode.justified}
                isHeaderVisible
                ariaLabelForSelectionColumn="Toggle selection"
                ariaLabelForSelectAllCheckbox="Toggle selection for all items"
              />
            </div>
          </div>
          <div className="col-xs-3 activity-container">
            <div className="col-xs-12" style={{ padding: "18px 15px" }}>
              <b className="heading">Activity</b>
              <Link to="activityLog" className="pull-right">
                Detail view
              </Link>
            </div>
            <div className="col-xs-12">
              {activityLog.map((d, i) => (
                <div className="activityLog" key={`test-${i}`}>
                  <div>
                    <b>{this.getName(d.userId, true)}</b>
                  </div>
                  {d.actionInformation}
                  <span color="green">-</span>
                  <div>
                    on {moment(d.timeStamp).format("ddd DD-MMM-YYYY hh:mm A")}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div
          className={`${showRightNav ? "show" : ""} addData`}
          style={{ width: showAMember || showIOrganization ? "550px" : "" }}
        >
          {showAddData && (
            <Adddata
              getResourceGroup={getResourceGroup}
              resourceGroupOptions={resourceGroupOptions}
              subscriptions={subscriptions}
              toggleData={this.toggleNav}
              postData={this.postDataSet}
              collaborationId={collaborationId}
            />
          )}
          {showIOrganization && (
            <InviteOrganization
              toggleData={this.toggleNav}
              collaborativeTerms={collaborativeTerms}
              organizations={organizations}
              inviteOrganization={this.inviteOrganization}
            />
          )}
          {showAMember && (
            <AddMembers
              organizations={organizations}
              members={members}
              roles={roles}
              toggleData={this.toggleNav}
              inviteMember={this.inviteMember}
            />
          )}
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log(state);
  const {
    collaborativeDetail,
    collaborativeTerms,
    members,
    organizations,
    roles,
    subscriptions,
    resourceGroupOptions
  } = state.collaboratives;
  return {
    resourceGroupOptions,
    collaborativeDetail,
    collaborativeTerms,
    members,
    organizations,
    roles,
    subscriptions
  };
}

function mapDispatchToProps(dispatch) {
  return {
    getCollaborativeDetail: collaborationId =>
      dispatch(getCollaborativeDetail(collaborationId)),
    getResourceGroup: subscriptionId =>
      dispatch(getResourceGroup(subscriptionId)),
    postData: (collaborationId, data, component) =>
      dispatch(postData(collaborationId, data, component)),
    inviteOrganization: (collaborationId, data, component) =>
      dispatch(inviteOrganization(collaborationId, data, component)),
    importDataSet: (collaborationId, data) =>
      dispatch(importDataSet(collaborationId, data)),
    inviteMember: (collaborationId, data, component) =>
      dispatch(inviteMember(collaborationId, data, component))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Collaborative);
