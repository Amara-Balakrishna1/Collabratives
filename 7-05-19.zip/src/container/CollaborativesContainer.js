import * as React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import moment from "moment";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { FocusZone } from "office-ui-fabric-react/lib/FocusZone";
import { List } from "office-ui-fabric-react/lib/List";
import { CommandBarButton } from "office-ui-fabric-react/lib/Button";
import AddDialog from "../components/Collaboratives/AddCollaborative";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import {
  getCollaboratives,
  createCollaborative
} from "../actions/collaborativesActions";
import { getResourceGroup } from "../actions/collaborativeInviteAction";
import "./CollaborativesContainer.scss";
import { Persona, PersonaSize } from "office-ui-fabric-react";

const ROWSPERPAGE = 3;
const MAXROWHEIGHT = 250;

class ListGridExample extends React.Component {
  constructor(props) {
    super(props);
    // const user = "5F304F82-1A81-459C-80B1-89D107FC9262"; //"8a2905e6-03a3-4027-82ae-ed0b8bce69b8" //normal user
    // const admin = "810917c0-9083-4afa-b783-caa9010dc806"; // admin

    // const r = window.confirm("Choose the user");
    // if (r == true) {
    //   sessionStorage.setItem("userID", admin);
    // } else {
    //   sessionStorage.setItem("userID", user);
    // }
    this.state = {
      showDialog: false,
      collaboratives: [],
      createCollab: false
    };
  }
  toggleDialog = value => {
    const { showDialog } = this.state;
    this.setState({
      showDialog: !showDialog,
      createCollab: value !== false
    });
  };
  static getDerivedStateFromProps(nextProps) {
    return {
      collaboratives: nextProps.collaboratives || []
    };
  }
  render() {
    const { collaboratives, showDialog, createCollab } = this.state;
    const {
      industries,
      formats,
      createCollaborative,
      resourceGroupOptions,
      subscriptions,
      getResourceGroup
    } = this.props;
    const adminOf = collaboratives.filter(d => d.isAdmin);
    const memOf = collaboratives.filter(d => !d.isAdmin);
    return (
      <div className="Collaboratives">
        {sessionStorage.getItem("userID") ===
        "810917c0-9083-4afa-b783-caa9010dc806" ? (
          <div className="col-xs-12 addRow">
            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={this.toggleDialog}
              text="Create New Collaborative"
            />
          </div>
        ) : null}

        <Pivot className="col-xs-12">
          <PivotItem itemKey="pivotItemKey_0" headerText="Admin of">
            <div className="col-xs-12 count hide">
              My Collaboratives({adminOf.length})
            </div>
            <FocusZone>
              <List
                className="ms-ListGridExample Lists"
                items={adminOf}
                getItemCountForPage={this.getItemCountForPage}
                getPageHeight={this.getPageHeight}
                renderedWindowsAhead={4}
                onRenderCell={this.onRenderCell}
              />
            </FocusZone>
          </PivotItem>
          <PivotItem itemKey="pivotItemKey_1" headerText="Member of">
            <div className="col-xs-12 count hide">
              My Collaboratives({memOf.length})
            </div>
            <FocusZone>
              <List
                className="ms-ListGridExample Lists"
                items={memOf}
                getItemCountForPage={this.getItemCountForPage}
                getPageHeight={this.getPageHeight}
                renderedWindowsAhead={4}
                onRenderCell={this.onRenderCell}
              />
            </FocusZone>
          </PivotItem>
        </Pivot>

        {createCollab && (
          <AddDialog
            showDialog={showDialog}
            toggleDialog={this.toggleDialog}
            industriesd={industries}
            formats={formats}
            getResourceGroup={getResourceGroup}
            subscriptions={subscriptions}
            resourceGroupOptions={resourceGroupOptions}
            createCollaborative={createCollaborative}
          />
        )}
      </div>
    );
  }
  componentDidMount() {
    const { getCollaboratives } = this.props;
    getCollaboratives();
  }
  getItemCountForPage = (itemIndex, surfaceRect) => {
    if (itemIndex === 0) {
      this.columnCount = 4;
      this.columnWidth = Math.floor(surfaceRect.width / this.columnCount);
      this.rowHeight = MAXROWHEIGHT;
    }

    return this.columnCount * ROWSPERPAGE;
  };

  getPageHeight = () => {
    return this.rowHeight * ROWSPERPAGE;
  };

  onRenderCell = (item, index) => {
    const { organizations, information, collaborationId } = item;
    const { name, imageUrl, lastUpdatedAt } = Object(information);
    return (
      <Link to={{ pathname: `/collaborative/${collaborationId}` }}>
        <div
          className="ms-ListGridExample-tile"
          data-is-focusable={true}
          style={{
            width: "260px",
            height: "316px",
            float: "left",
            display: "inline-block",
            margin: "10px 0px 0px 15px"
          }}
        >
          <div className="ms-ListGridExample-sizer">
            <div className="msListGridExample-padder">
              <img
                src={imageUrl}
                alt="collaborativeImage"
                className="ms-ListGridExample-image"
              />

              <div className="name">{name}</div>
              {/* <div className="info-1">
                Last Modified:{" "}
                {moment(lastUpdatedAt).format("ddd DD-MMM-YYYY hh:mm A")}{" "}
              </div> */}
              <div className="info-2">
                <Icon iconName="CityNext2" className="ms-IconExample" />
                {organizations.length} collaborating organizations:
                <div className="org-icons">
                  {organizations.map(d => (
                    <div>
                      <Persona
                        size={PersonaSize.size32}
                        imageUrl={d.organizationLogo}
                      />
                      {d.organizationName === "Microsoft" ? <div className="pill">Admin</div> : null}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </Link>
    );
  };
}

function mapStateToProps(state) {
  console.log(state);
  const {
    collaboratives,
    industries,
    formats,
    subscriptions,
    resourceGroupOptions
  } = state.collaboratives;
  return {
    collaboratives,
    industries,
    formats,
    subscriptions,
    resourceGroupOptions
  };
}

function mapDispatchToProps(dispatch) {
  return {
    getCollaboratives: () => dispatch(getCollaboratives()),
    createCollaborative: data => dispatch(createCollaborative(data)),
    getResourceGroup: subscriptionId =>
      dispatch(getResourceGroup(subscriptionId))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ListGridExample);
