import React, { Component } from "react";
import { Label } from "office-ui-fabric-react/lib/Label";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton, Dropdown } from "office-ui-fabric-react";
import {
  Persona,
  PersonaSize
  // PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
import Wrapper from "./Addwrapper";
import "./inviteMembers.scss";

class AddMember extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formFields: {
        memberName: "",
        email: "",
        organizationName: "",
        role: ""
      },
      options: props.organizations.map(d => ({
        key: d.organizationName,
        text: d.organizationName,
        organizationId: d.azureOrgId
      })),
      roleOptions: props.roles.map(d => ({
        key: d,
        text: d
      })),
      members: props.members
    };
  }
  onChange = (field, value) => {
    const { formFields } = this.state;

    // const result = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    // if (field === "adminEmail" && !result) {
    // } else {
    formFields[field] = value;
    // }
    this.setState({
      formFields
    });
  };
  render() {
    const { toggleData } = this.props;
    const {
      formFields: { email, organizationName, role },
      options,
      roleOptions,
      members
    } = this.state;
    return (
      <Wrapper
        className="showAMember"
        toggleData={toggleData}
        name="showAMember"
      >
        <div
          className="row"
          style={{ height: "200px", padding: "20px", margin: "0px" }}
        >
          <Label>Invite Members</Label>
          {/* <TextField
            label="Member Name"
            value={memberName}
            onChange={(ev, value) => this.onChange("memberName", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          /> */}
          <div className="col-xs-12" style={{ paddingLeft: "0px" }}>
            <Dropdown
              label="Organization"
              options={options}
              placeholder="Select Organization"
              // selectedKey={organizationName}
              onChange={(ev, value) =>
                this.onChange("organizationName", value.organizationId)
              }
            />
          </div>
          <div className="col-xs-7" style={{ paddingLeft: "0px" }}>
            <TextField
              label="Email"
              value={email}
              onChange={(ev, value) => this.onChange("email", value)}
              placeholder="Ex. John@abc.com"
              className="collab-field"
              styles={{ padding: "5px" }}
            />
          </div>
          <div className="col-xs-5">
            <Dropdown
              label="Role"
              options={roleOptions}
              selectedKey={role}
              placeholder="Select Role"
              onChange={(ev, value) => this.onChange("role", value.key)}
            />
          </div>
        </div>

        <div className="row" style={{ padding: "0 20px", margin: "0px" }}>
          <PrimaryButton
            text="Invite"
            onClick={() => {
              const { role, organizationName, email } = this.state.formFields;
              const payload = {
                memberEmailId: email,
                organizationId: organizationName,
                memberRole: role
              };
              this.props.inviteMember(payload);
            }}
          />
        </div>
        <hr />
        <div
          className="row mem-container"
          
        >
          <Label className="heading">Members</Label>
          <div className="row members">
            <table>
              <thead>
                <tr>
                  <td>Email</td>
                  <td>Organization</td>
                  <td>Role</td>
                </tr>
              </thead>
              <tbody>
                {members.map((d, i) => (
                  <tr>
                    <td>
                      <Persona
                        // imageUrl={d.imageUrl}
                        text={d.emailId}
                        imageInitials=""
                        size={PersonaSize.size28}
                      />
                    </td>
                    <td>{d.organizationName}</td>
                    <td>
                      <Dropdown
                        options={roleOptions}
                        selectedKey={d.userRole}
                        defaultSelectedKey={d.userRole}
                        onChange={
                          (ev, value) => {
                            console.log(value);
                            const { members } = this.state;
                            members[i].userRole = value.key;
                            console.log(members);
                            this.setState({
                              members
                            });
                          }
                          // this.onChange("role", value.key)
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Wrapper>
    );
  }
}

export default AddMember;
