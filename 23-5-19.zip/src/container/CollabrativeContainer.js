import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import { CommandBarButton, Button } from "office-ui-fabric-react/lib/Button";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  Persona,
  PersonaSize,
  PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
// import { List } from "office-ui-fabric-react/lib/List";
import {
  DetailsList,
  DetailsRow,
  DetailsListLayoutMode,
  SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { Callout } from "office-ui-fabric-react/lib/Callout";
// import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { mergeStyleSets } from "office-ui-fabric-react/lib/Styling";
import { getCollabrativeDetail } from "../actions/collaborativesActions";
import "./CollabrativeContainer.scss";

const uuidv1 = require("uuid/v1");

const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: "16px"
  },
  fileIconCell: {
    textAlign: "center",
    selectors: {
      "&:before": {
        content: ".",
        display: "inline-block",
        verticalAlign: "middle",
        height: "100%",
        width: "0px",
        visibility: "hidden"
      }
    }
  },
  fileIconImg: {
    verticalAlign: "middle",
    maxHeight: "16px",
    maxWidth: "16px"
  },
  controlWrapper: {
    display: "flex",
    flexWrap: "wrap"
  },
  exampleToggle: {
    display: "inline-block",
    marginBottom: "10px",
    marginRight: "30px"
  },
  selectionDetails: {
    marginBottom: "20px"
  }
});
// const controlStyles = {
//   root: {
//     margin: '0 30px 20px 0',
//     maxWidth: '300px'
//   }
// };

// const examplePersona = {
//   // imageUrl: TestImages.personaFemale,
//   imageInitials: "AL",
//   text: "Annie Lindqvist",
//   secondaryText: "Software Engineer",
//   tertiaryText: "In a meeting",
//   optionalText: "Available at 4:00pm"
// };

class Collabrative extends Component {
  constructor(props) {
    super(props);
    const that = this;
    
    that.t2 = React.createRef();
    const columns = [
      {
        key: "column1",
        name: "File Type",
        className: classNames.fileIconCell,
        iconClassName: classNames.fileIconHeaderIcon,
        ariaLabel:
          "Column operations for File type, Press to sort on File type",
        iconName: "Page",
        isIconOnly: true,
        fieldName: "name",
        minWidth: 16,
        maxWidth: 16,
        onRender: item => (
          <div>
            <Icon
              style={{ fontSize: "16px" }}
              iconName="FabricFolderFill"
              className="ms-IconExample"
            />
          </div>
        )
      },
      {
        key: "column2",
        name: "Name",
        fieldName: "name",
        minWidth: 110,
        maxWidth: 250,
        isRowHeader: true,
        isResizable: true,
        isSorted: true,
        isSortedDescending: false,
        sortAscendingAriaLabel: "Sorted A to Z",
        sortDescendingAriaLabel: "Sorted Z to A",

        data: "string",
        isPadded: true
      },
      {
        key: "column3",
        name: "Description",
        fieldName: "dateModifiedValue",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        data: "number",
        onRender: (item, index) => {
          return (
            <Icon
              iconName="Info"
              className="ms-IconExample"
              // ref={this[`t${index}`]}
              onMouseOver={(event) => {
                that.setState({
                  isCalloutVisible: true,
                  callDescription: `${item.description}${index}`,
                  callFrame: `${moment(item.dataStartDate).format(
                    "ddd DD-MMM-YYYY hh:mm A"
                  )}-${moment(item.dataEndDate).format(
                    "ddd DD-MMM-YYYY hh:mm A"
                  )}`,
                  top: event.clientX,
                  left: event.clientY
                });
              }}
              onMouseLeave={() => {
                this.setState({
                  isCalloutVisible: false
                });
              }}
            />
          );
        },
        isPadded: true
      },
      {
        key: "column4",
        name: "Shared By",
        fieldName: "modifiedBy",
        minWidth: 110,
        maxWidth: 150,
        isResizable: true,
        isCollapsible: true,
        data: "string",

        onRender: item => <span>{that.getName(item.ownerId)}</span>,
        isPadded: true
      },
      {
        key: "column5",
        name: "Size",
        fieldName: "fileSizeRaw",
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => <span>{item.sizeInGB}</span>
      },
      {
        key: "column6",
        name: "Last Modified",
        fieldName: "fileSizeRaw",
        minWidth: 150,
        maxWidth: 190,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <span>
            {moment(item.lastModified).format("ddd DD-MMM-YYYY hh:mm A")}
          </span>
        )
      },
      {
        key: "column7",
        name: "Status",
        fieldName: "fileSizeRaw",
        minWidth: 90,
        maxWidth: 120,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => <span>{item.status}</span>
      }
    ];
    const { collaborationId } = props.history.location;
    this.state = {
      collaborationId,
      columns
    };
  }
  componentDidMount() {
    const { getCollabrativeDetail } = this.props;
    const { collaborationId } = this.state;
    getCollabrativeDetail(collaborationId);
  }
  static getDerivedStateFromProps(nextProps) {
    const { activityLog = [], dataSets = [] } = Object(
      nextProps.collaborativeDetail
    );
    return {
      items: dataSets || [],
      activityLog
    };
  }
  onRenderRow = props => {
    return (
      <DetailsRow
        {...props}
        styles={{
          root: {
            backgroundColor: props.item.status === "Pending" ? "#FFF4CE" : ""
          }
        }}
      />
    );
  };
  getName = (id, log) => {
    const { collaborators = [] } = this.props.collaborativeDetail;
    const obj = collaborators.filter(d => d.id === id)[0] || {};
    if (log) {
      return `${obj.organizationName}(${obj.fullName})` || "";
    }
    return `${obj.fullName}(${obj.emailId})` || "";
  };
  getInitials(name = "") {
    const arr = name ? name.split(".") : [[], []];
    return `${(arr[0][0] || "").toUpperCase()}${(
      arr[1][0] || ""
    ).toUpperCase()}`;
  }
  render() {
    const {
      columns,
      isCompactMode,
      items,
      isModalSelection,
      activityLog,
      isCalloutVisible,
      callDescription,
      callFrame,
      top,
      left
    } = this.state;
    const { collaborators = [], information = {} } = Object(
      this.props.collaborativeDetail
    );
    const admin =
      collaborators.filter(d => d.userRole === "CollaborativeAdmin")[0] || {};
    const nonAdmin = collaborators.filter(
      d => d.userRole !== "CollaborativeAdmin"
    );
    return (
      <div className="detail-collabarative">
        <div className="col-xs-12 addRow">
          <div className="col-xs-11">
            
              <div 
                className="ms-CalloutExample-callout"
                style={{ position: 'fixed', top, left, display: isCalloutVisible ? '' : 'none' }}
              >
                <div>{callDescription}</div>
                <div>{callFrame}</div>
              </div>
            
            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={() => {
                console.log("adfasd");
              }}
              text="Add Data"
              ref={this.t2}
            />

            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={() => {
                console.log("adfasd");
              }}
              text="Invite Organization"
            />
            <CommandBarButton
              iconProps={{ iconName: "Add" }}
              onClick={() => {
                console.log("adfasd");
              }}
              text="Add Members"
            />
          </div>
          <div className="col-xs-1">
            <Icon iconName="Info" className="ms-IconExample" />
          </div>
        </div>
        <div className="col-xs-12 collabInfo">
          <div className="col-xs-7">
            <Persona
              imageUrl={information.imageUrl}
              text={information.name}
              secondaryText={information.defaultAzureStorageLocation}
              size={PersonaSize.size72}
              onRenderPrimaryText={data => (
                <div style={{ fontSize: "24px" }}>{data.text}</div>
              )}
              onRenderSecondaryText={data => (
                <div>
                  <b>Default Location: </b>
                  {(data.secondaryText || "").substring(0, 30)}
                  <a href="test">Change</a>
                </div>
              )}
            />
          </div>
          <div className="col-xs-5 ">
            <div className="persons">
              <div className="col-xs-3">Collaborative Admin:</div>
              <div className="col-xs-9">
                <Persona
                  text={
                    admin.fullName
                      ? `${admin.fullName} (${admin.organizationName})`
                      : ""
                  }
                  size={PersonaSize.size32}
                  imageInitials={this.getInitials(admin.userName)}
                />
              </div>
            </div>
            <div className="persons">
              <div className="col-xs-3">Collaborators({nonAdmin.length}):</div>
              <div className="col-xs-9 persona-list">
                {nonAdmin.map(item => (
                  <Persona
                    key={`${item.userName}-12`}
                    {...item}
                    size={PersonaSize.size32}
                    imageInitials={this.getInitials(item.userName)}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="col-xs-12 dataInfo">
          <div className="col-xs-9 data-container">
            <div className="col-xs-12 data">
              <div className="col-xs-4">
                <div className="storage-details">235</div>
                <div className="storage-label">GB of Data</div>
              </div>
              <div className="col-xs-4">
                <div className="storage-details">4</div>
                <div className="storage-label">Members</div>
              </div>
              {/* <div className="col-xs-3">
                <div className="storage-details" >&nbsp;</div>
                <div className="storage-label">
                  Volume Trends
                </div>
              </div> */}
              <div className="col-xs-4">
                <div className="storage-details">1</div>
                <div className="storage-label">Models</div>
              </div>
            </div>
            <div
              className="col-xs-12"
              style={{
                fontFamily: "Segoe UI",
                fontSize: "20px",
                height: "52px",
                padding: "0px 10px"
              }}
            >
              Collaborative Data
            </div>
            <div className="col-xs-12 dataList">
              <DetailsList
                items={items}
                compact={isCompactMode}
                columns={columns}
                selectionMode={
                  isModalSelection ? SelectionMode.multiple : SelectionMode.none
                }
                onRenderRow={this.onRenderRow}
                setKey="set"
                layoutMode={DetailsListLayoutMode.justified}
                isHeaderVisible
                ariaLabelForSelectionColumn="Toggle selection"
                ariaLabelForSelectAllCheckbox="Toggle selection for all items"
              />
            </div>
          </div>
          <div className="col-xs-3 activity-container">
            <div className="col-xs-12">
              <b className="heading">Activity</b>
              <a className="pull-right">Activity Details</a>
            </div>
            <div className="col-xs-12">
              {activityLog.map((d, i) => (
                <div className="activityLog" key={`test-${i}`}>
                  <div>
                    <b>{this.getName(d.userId, true)}</b>
                  </div>
                  {d.actionInformation}
                  <span color="green">-</span>
                  <div>
                    on {moment(d.timeStamp).format("ddd DD-MMM-YYYY hh:mm A")}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log(state);
  const { collaborativeDetail } = state.collaboratives;
  return {
    collaborativeDetail
  };
}

function mapDispatchToProps(dispatch) {
  return {
    getCollabrativeDetail: collaborationId =>
      dispatch(getCollabrativeDetail(collaborationId))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Collabrative);
