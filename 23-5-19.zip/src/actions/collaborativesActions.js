import axios from "axios";
import config from "./config";
import urls from "./actionURLS";

export const GET_COLLABRATIVES = "GET_COLLABRATIVES";
export const GET_COLLABRATIVEDETAILS = "GET_COLLABRATIVEDETAILS";

export function getCollaboratives() {
  const arr = [
    axios.get(`${urls.getAllCollabratives}`, config),
    axios.get(`${urls.getIndustries}`, config),
    axios.get(`${urls.getFormats}`, config)
  ]
  return dispatch => {
    axios.all(arr)
      .then(axios.spread((list, industries, formats) => {
        dispatch({
          type: GET_COLLABRATIVES,
          data: list.data,
          industries: industries.data,
          formats: formats.data
        });
      }))
      .catch();
  };
}

export function getCollabrativeDetail(collaborationId) {
  return dispatch => {
    console.log(`${urls.getCollabrativeInfo}${collaborationId}`);
    axios
      .get(`${urls.getCollabrativeInfo}${collaborationId}`, config)
      .then(result => {
        dispatch({
          type: GET_COLLABRATIVEDETAILS,
          data: result.data
        });
      })
      .catch( err => {
        console.log('error')
      });
  };
}