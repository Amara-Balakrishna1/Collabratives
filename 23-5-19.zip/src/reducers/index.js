import { combineReducers } from 'redux';
import collaboratives from './collaboratives';

export default combineReducers({
  collaboratives
})