import {
  GET_COLLABRATIVES,
  GET_COLLABRATIVEDETAILS
} from "../actions/collaborativesActions";

export default function visibilityFilter(state = {}, action) {
  switch (action.type) {
    case GET_COLLABRATIVES: {
      const { data = [], industries = [], formats = [] } = action;
      return { ...state, collaboratives: data, industries, formats };

    }
    case GET_COLLABRATIVEDETAILS:
      return {
        ...state,
        collaborativeDetail: action.data
      };
    default:
      return state;
  }
}
