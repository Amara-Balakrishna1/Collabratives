import React, { Component } from "react";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import {
  CommandBarButton,
  DefaultButton
} from "office-ui-fabric-react/lib/Button";
import { Dropdown } from "office-ui-fabric-react/lib/Dropdown";
import Fileinput from "./Fileinput";
import "./modalStyle.scss";
import { Label } from "office-ui-fabric-react";

const CollaborativeNameTitle = "Give your collaborative a meaningful name.";
const IndustryTitle = "Which Industry does this collaborative fall under?";
const GoalTitle =
  "Mention the end goal of having this collaborative, including the value you want to create out of the data. A clear goal helps all stakeholders be aligned and contribute meanigfully.";
const DataContextTitle =
  "What kinds of data is needed to achive your goal? What data do you want the members to share?";
const imageTitle =
  "Uploading an image for your collaborative makes it more interesting! You can change this any time.";
const StorageLocationTitle =
  "You can choose a default storage location where all the data recieved from the colloaborators should be stored. Make sure this is a secure location and that no other data is stored here. You can, at any point change this location in the future. ";
const RecommendedFormatTitle =
  "Tell collaborators what format of data would be need to be shared in the collaborative. If you don't find a format in the list, select Other.";
const SubscriptionTitle =
  "You can choose a default Subscription where all the data recieved from the colloaborators should be stored";
const ResourceTitle =
  "You can choose a default Resource where all the data recieved from the colloaborators should be stored";

const tcTitle =
  "Upload Terms and Conditions that all the collaborators must agree to.";
const ppTitle =
  "Upload Privacy related documents that all the collaborators must agree to.";

const labels = {
  name: "Collaborative Name",
  goal: "Goal",
  industries: "Industries",
  dataContext: "Data Context",
  storageLocation: "Storage Location",
  recommendedFormats: "Recommended Formats"
};
class AddCollab extends Component {
  constructor(props) {
    super(props);

    this.state = {
      formFields: {
        imageUrl: ""
      },
      tcArray: [
        {
          policyName: "Terms and Conditions"
        },
        {
          policyName: "Privacy Policy"
        }
      ],
      newFields: [],
      subscriptionIds: props.subscriptions,
      storageLocationOptions: props.storageLocationOptions || [],
      resourceGroupNames: props.resourceGroupOptions || []
    };
  }
  static getDerivedStateFromProps(nextProps) {
    return {
      subscriptionIds: nextProps.subscriptions,
      resourceGroupNames: nextProps.resourceGroupOptions,
      storageLocationOptions: nextProps.storageLocationOptions
    };
  }
  onRenderDescription = (props, data) => (
    <Stack horizontal verticalAlign="center">
      <span className={props.required ? "req" : ""}>{props.label}</span>
      <Icon
        iconName="Info"
        ariaLabel="Info"
        onMouseLeave={this.onMouseLeave}
        onMouseOver={event => {
          this.onMouseOver(event, data);
        }}
      />
    </Stack>
  );
  setActiveTab = index => {
    this.setState({
      selectedPivotKey: "pivotItemKey_" + index
    });
  };
  onChange = (field, value) => {
    const { formFields } = this.state;
    formFields[field] = value;
    this.setState({
      formFields
    });
  };
  fileChange = (root, index, data, name, fileContent = {}) => {
    const subData = this.state[root];
    subData[index].documentUrl = data;
    subData[index].fileContent = fileContent;
    subData[index].policyName = subData[index].policyName;
    subData[index].documentName = fileContent.name;
    this.setState({
      [root]: subData
    });
  };
  setTCName = (index, data) => {
    const subData = this.state.newFields;
    subData[index].policyName = data;
    this.setState({
      newFields: subData
    });
  };
  validateFields = flag => {
    const reqFields = [
      "name",
      "goal",
      "industries",
      "dataContext",
      "storageLocation",
      "recommendedFormats"
    ];
    const { formFields } = this.state;
    const emptyFields = [];
    reqFields.forEach(d => {
      if (!formFields[d]) {
        emptyFields.push(labels[d]);
      }
    });
    if (flag) {
      this.setState({
        emptyFields
      });
    }
    return Boolean(emptyFields.length);
  };
  onMouseOver = (event, calloutData) => {
    this.setState({
      isCalloutVisible: true,
      calloutData,
      top: event.clientY,
      left: event.clientX + 15
    });
  };
  onMouseLeave = () => {
    this.setState({
      isCalloutVisible: false
    });
  };
  render() {
    const {
      showDialog,
      toggleDialog,
      industriesd = [],
      formats = []
    } = this.props;
    const {
      formFields: {
        name,
        goal,
        industries = [],
        dataContext,
        storageLocation,
        subscriptionId,
        resourceGroupName,
        recommendedFormats = []
      },
      tcArray,
      newFields,
      selectedPivotKey,
      subscriptionIds = [],
      resourceGroupNames = [],
      storageLocationOptions = [],
      isCalloutVisible,
      top,
      left,
      calloutData,
      emptyFields = []
    } = this.state;
    return (
      <Modal
        isOpen
        className={showDialog ? "" : "hide"}
        isBlocking={false}
        containerClassName="container"
      >
        {isCalloutVisible && (
          <div
            className="ms-CalloutExample-callout"
            style={{
              zIndex: 99,
              position: "fixed",
              top,
              left
            }}
          >
            <div>{calloutData}</div>
          </div>
        )}
        <div className="header">
          <div className="col-xs-11" style={{ padding: "8px" }}>
            Create Collaborative
          </div>
          <div className="col-xs-1 pull-right" style={{ textAlign: "right" }}>
            <Icon
              iconName="Cancel"
              className="ms-IconExample"
              onClick={toggleDialog}
            />
          </div>
        </div>
        <div className="row fixed-row">
          <Pivot className="tabHeader" selectedKey={selectedPivotKey}>
            <PivotItem
              onLinkClick={() => this.setActiveTab(0)}
              itemKey="pivotItemKey_0"
              headerText="Collaborative Details"
              style={{
                height: "100%",
                display: "flex",
                flexDirection: "column"
              }}
            >
              <div className="row" style={{ flex: 15, overflow: "auto" }}>
                <div className="col-xs-12">
                  This information will be send to Collaborators you invite
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Collaborative Name"
                    value={name}
                    onChange={(ev, value) => this.onChange("name", value)}
                    required
                    placeholder="Ex. Enter Collaborative Name"
                    className="collab-field"
                    onRenderLabel={props =>
                      this.onRenderDescription(props, CollaborativeNameTitle)
                    }
                  />
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="req">Select Industry</span>
                        <Icon
                          iconName="Info"
                          ariaLabel="Info"
                          onMouseLeave={this.onMouseLeave}
                          onMouseOver={event => {
                            this.onMouseOver(event, IndustryTitle);
                          }}
                        />
                      </Stack>
                      <Dropdown
                        selectedKeys={industries}
                        multiSelect
                        placeholder="Select Industry"
                        onChange={(ev, value) => {
                          if (value.selected) {
                            industries.push(value.key);
                          } else {
                            industries.splice(industries.indexOf(value.key), 1);
                          }
                          this.onChange("industries", industries);
                        }}
                        // onRenderTitle={this.onRenderDescription}
                        options={industriesd.map(d => ({
                          key: d,
                          text: d
                        }))}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Goal"
                    value={goal}
                    onChange={(ev, value) => {
                      this.onChange("goal", value);
                    }}
                    required
                    placeholder="Why does this collaborative exist? What is end goal?"
                    className="collab"
                    onRenderLabel={props =>
                      this.onRenderDescription(props, GoalTitle)
                    }
                    multiline
                  />
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Data context"
                    value={dataContext}
                    onChange={(ev, value) => {
                      this.onChange("dataContext", value);
                    }}
                    required
                    placeholder="Ex. Description of the data?"
                    className="collab-field"
                    onRenderLabel={props =>
                      this.onRenderDescription(props, DataContextTitle)
                    }
                  />
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <div className="ms-Stack">
                        <span className=""> Collaborative Image</span>
                        <Icon
                          iconName="Info"
                          ariaLabel="Info"
                          onMouseLeave={this.onMouseLeave}
                          onMouseOver={event => {
                            this.onMouseOver(event, imageTitle);
                          }}
                        />
                      </div>
                      <div
                        className="ms-TextField-fieldGroup"
                        style={{ border: "none" }}
                      >
                        <Fileinput
                          typeImg
                          fileChange={this.onChange}
                          id="image"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="">Subscription Id</span>
                        <Icon
                          iconName="Info"
                          ariaLabel="Info"
                          onMouseLeave={this.onMouseLeave}
                          onMouseOver={event => {
                            this.onMouseOver(event, SubscriptionTitle);
                          }}
                        />
                      </Stack>
                      <Dropdown
                        selectedKey={subscriptionId}
                        placeholder={`Ex. Select Subscription`}
                        onChange={(ev, value) => {
                          this.onChange("subscriptionId", value.key);
                          this.props.getResourceGroup(value.key);
                        }}
                        options={subscriptionIds.map(d => ({
                          text: d.resourceName,
                          key: d.subscriptionId
                        }))}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="">Resource Group Name</span>
                        <Icon
                          iconName="Info"
                          ariaLabel="Info"
                          onMouseLeave={this.onMouseLeave}
                          onMouseOver={event => {
                            this.onMouseOver(event, ResourceTitle);
                          }}
                        />
                      </Stack>
                      <Dropdown
                        selectedKey={resourceGroupName}
                        placeholder={`Ex. Select Resource Group`}
                        onChange={(ev, value) => {
                          this.onChange("resourceGroupName", value.key);
                          this.props.getStorageLocations(
                            subscriptionId,
                            value.key
                          );
                        }}
                        options={resourceGroupNames.map(d => ({
                          key: d,
                          text: d
                        }))}
                      />
                    </div>
                  </div>
                </div>

                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="">Default Storage Location</span>
                        <Icon
                          iconName="Info"
                          ariaLabel="Info"
                          onMouseLeave={this.onMouseLeave}
                          onMouseOver={event => {
                            this.onMouseOver(event, StorageLocationTitle);
                          }}
                        />
                      </Stack>
                      <Dropdown
                        selectedKey={storageLocation}
                        placeholder={`Ex. Select Resource Group`}
                        onChange={(ev, value) => {
                          this.onChange("storageLocation", value.key);
                        }}
                        options={storageLocationOptions.map(d => ({
                          key: d,
                          text: d
                        }))}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="req">Recommended Format</span>
                        <Icon
                          iconName="Info"
                          ariaLabel="Info"
                          onMouseLeave={this.onMouseLeave}
                          onMouseOver={event => {
                            this.onMouseOver(event, RecommendedFormatTitle);
                          }}
                        />
                      </Stack>
                      <Dropdown
                        selectedKeys={recommendedFormats}
                        placeholder="Select Recommended Format"
                        onChange={(ev, value) => {
                          if (value.selected) {
                            recommendedFormats.push(value.key);
                          } else {
                            recommendedFormats.splice(
                              recommendedFormats.indexOf(value.key),
                              1
                            );
                          }
                          this.onChange(
                            "recommendedFormats",
                            recommendedFormats
                          );
                        }}
                        multiSelect
                        options={formats.map(d => ({
                          key: d,
                          text: d
                        }))}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="col-xs-12"
                style={{ borderTop: "1px solid #ccc" }}
              >
                <PrimaryButton
                  style={{ margin: "5px 0px" }}
                  text="Continue"
                  // disabled={this.validateFields()}
                  onClick={() => {
                    const flag = this.validateFields(true);
                    if (!flag) {
                      this.setActiveTab(1);
                    }
                  }}
                />
                {emptyFields.length ? (
                  <div
                    style={{
                      display: "inline-block",
                      padding: "10px 5px",
                      color: "red"
                    }}
                  >
                    Please fill {emptyFields.join(", ")}
                  </div>
                ) : null}
              </div>
            </PivotItem>
            <PivotItem
              itemKey="pivotItemKey_1"
              headerText="Terms of Use"
              style={{
                height: "100%",
                display: "flex",
                flexDirection: "column"
              }}
              className="TC"
            >
              <div
                className="table"
                style={{ flex: 15, overflow: "auto", marginBottom: "0px" }}
              >
                <div className="row">
                  Upload Legal documents you would like all collaborators to
                  accept or adhere by
                </div>
                {tcArray.map((d, i) => (
                  <div className="row">
                    <div className="collab-field">
                      <div className="ms-TextField-wrapper">
                        <Stack horizontal verticalAlign="center">
                          <span>{d.policyName}</span>
                          <Icon
                            iconName="Info"
                            ariaLabel="Info"
                            onMouseLeave={this.onMouseLeave}
                            onMouseOver={event => {
                              this.onMouseOver(
                                event,
                                i === 0 ? tcTitle : ppTitle
                              );
                            }}
                          />
                        </Stack>
                        <div
                          className="ms-TextField-fieldGroup"
                          style={{ border: "none" }}
                        >
                          <Fileinput
                            root="tcArray"
                            label={d.documentName}
                            id={`tc-${i}`}
                            index={i}
                            fileChange={this.fileChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {newFields.length ? (
                  <div className="newFields">
                    {newFields.map((d, i) => (
                      <div className="row moreField">
                        <div className="collab-field">
                          <TextField
                            value={d.policyName}
                            onChange={(ev, value) => {
                              this.setTCName(i, value);
                            }}
                            placeholder="Ex. Label"
                          />
                          <Fileinput
                            root="newFields"
                            label={d.documentName}
                            id={`nf-${i}`}
                            index={i}
                            fileChange={this.fileChange}
                          />
                          <DefaultButton
                            className="pull-right removeButton"
                            style={{ background: "none", color: "#0078D4" }}
                            onClick={() => {
                              newFields.splice(i, 1);
                              this.setState({
                                newFields
                              });
                            }}
                            text="remove"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : null}
                <div className="col-xs-12" style={{ padding: "20px 10px" }}>
                  <CommandBarButton
                    iconProps={{ iconName: "Add" }}
                    style={{ background: "none", color: "#0078D4" }}
                    onClick={() => {
                      newFields.push({});
                      this.setState({
                        newFields
                      });
                    }}
                    text="Add More"
                  />
                </div>
              </div>
              <div
                className="col-xs-12"
                style={{ borderTop: "1px solid #ccc" }}
              >
                <DefaultButton
                  style={{ margin: "5px 0px" }}
                  text="Back"
                  // disabled={this.validateFields()}
                  onClick={() => this.setActiveTab(0)}
                />
                <PrimaryButton
                  style={{ margin: "5px 0px" }}
                  className="pull-right"
                  text="Continue"
                  disabled={this.validateFields()}
                  onClick={() => {
                    const {
                      formFields = {},
                      newFields = [],
                      tcArray = []
                    } = this.state;
                    const data = {
                      ...formFields,
                      termsOfUses: [...newFields, ...tcArray].filter(
                        d => d.documentUrl
                      ),
                      industries: formFields.industries,
                      defaultStorageAccountId: formFields.storageLocation
                    };
                    this.props.createCollaborative(data);
                    this.props.toggleDialog(false);
                  }}
                />
              </div>
            </PivotItem>
          </Pivot>
        </div>
      </Modal>
    );
  }
}

export default AddCollab;
