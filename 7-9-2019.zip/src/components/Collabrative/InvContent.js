import React from "react";
import moment from "moment";
import { Label, Icon, Persona, PersonaSize } from "office-ui-fabric-react";

class InvContent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      ...props
    };
  }
  static getDerivedStateFromProps(nextProps) {
    return {
      invitationInfo: nextProps.invitationInfo
    };
  }
  render() {
    const {
      invitedAt,
      showAddInfo,
      invitationInfo: { information = {},
        collaborators = [] }
    } = this.state;
    const {
      name = "",
      goal = "",
      dataContext = "",
      dataFormats = [],
      industries = []
    } = information;
    const adminInfo = collaborators.find(
      d => d.userRole === "CollaborativeAdmin"
    ) || {};
    const acceptedList = collaborators.filter(d => d.userStatus === "Accepted");
    return (
      <div className="inv-content">
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Collaborative Name</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">{name}</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Goal</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">{goal}</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Industry</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">{industries.join(", ")}</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Data Context</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">{dataContext}</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Recommended Format</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">{dataFormats.join(", ")}</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Sort By(Admin Organization)</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">{`${adminInfo.organizationName} (${
              adminInfo.fullName
              })`}</Label>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Received On</Label>
          </div>
          <div className="col-xs-6 text-left">
            <Label className="value">
              {moment(invitedAt).format("ddd DD-MMM-YYYY hh:mm A")}
            </Label>
          </div>
        </div>
        <div
          className={`row orgData ${showAddInfo ? 'showAddInfo' : ''}`}
          onClick={() => {
            this.setState({
              showAddInfo: !showAddInfo
            });
          }}
        >
          <div className="col-xs-offset-1 col-xs-3">
            <Label className="key">Collaborating Organization</Label>
          </div>
          <div className="col-xs-6 text-left" style={{ position: "relative" }}>
            <div>
              <Label className="value">{`${
                acceptedList.length
                } accepted; ${collaborators.length -
                acceptedList.length} invited`}</Label>
            </div>

          </div>
          <div className="col-xs-1">
            <Icon iconName={showAddInfo ? 'ChevronUp' : 'ChevronDown'} className="ms-IconExample" />
          </div>
          {showAddInfo ? (
            <div className=" col-xs-offset-4 col-xs-6 addInfo">
              <table
                style={{ width: "100%", color: "#323130", fontSize: "14px" }}
              >
                {collaborators.map((d, i) => (
                  <tr style={{ height: "35px" }}>
                    <td>
                      <Persona
                        size={PersonaSize.size32}
                        primaryText={`${d.organizationName} (${d.fullName})`}
                        imageUrl={d.organizationLogo}
                      />
                    </td>
                    <td>{d.userRole === "Collaborator" ? d.userStatus : '-'}</td>
                  </tr>
                ))}
              </table>
            </div>
          ) : null}
        </div>
      </div>
    );
  }
}
export default InvContent;
