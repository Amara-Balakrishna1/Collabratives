import React, { Component } from "react";
// import ReactDOM from "react-dom";
import { Icon, IconType } from "office-ui-fabric-react/lib/Icon";
import { Link } from "react-router-dom";
import IconOne from "../images/IconOne.png";
import LoginImg from "../images/Login.png";
import "./Login.scss";
import { Label, DefaultButton, PrimaryButton } from "office-ui-fabric-react";

// const serverURL = "https://collaborativesfunctions.azurewebsites.net/api/";
const serverURL = "https://collaborativesfunctionsforpm.azurewebsites.net/api/";

class Login extends Component {
  prepareURLS(userID) {
    sessionStorage.setItem("userID", userID)
    const userURL = `${serverURL}users/${userID}`;
    const commInvite = `${serverURL}users/${userID}/collaborations/`;

    const url = {
      getAllCollaboratives: `${serverURL}users/${userID}/collaborations`,
      getIndustries: `${serverURL}industries`,
      getFormats: `${serverURL}formats`,
      getCollaborativeInfo: `${serverURL}users/${userID}/collaborations/`,
      postCollaboration: `${serverURL}users/${userID}/collaborations`,
      fileUpload: `${serverURL}files`,
      postData: `${serverURL}users/${userID}/collaborations/`,
      //comm  invite
      // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/inviteorganization`
      // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/invitemember
      // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/join
      // inviteorganization:`${serverURL}users/${userId}/collaborations/`,//{collaborationId}/organizations get call
      // inviteorganization:`${serverURL}users/${userId}/collaborations/`terms`,//{collaborationId}/terms get call
      //comm for invite
      userURL,
      commInvite,
      // get dropdowns
      getMemberroles: `${serverURL}memberroles`,
      getMemberStatuses: `${serverURL}memberstatuses`
      // get dropdowns
    };
    window.urls = url;
  }
  render() {
    return (
      <div className="login">
        <div className="half">
          <img className="bgImage" src={LoginImg} />
          <div className="content text-center">
            <div className="row header">
              <Icon
                // iconName="Waffle"
                iconType={IconType.image}
                className="ms-IconExample"
                styles={{ width: "auto", height: "30px" }}
                imageProps={{
                  src: IconOne
                }}
              />
            </div>
            <div
              className="row"
              style={{
                fontWeight: 350,
                fontSize: "48px"
              }}
            >
              Microsoft Collaboratives
            </div>
            <div
              className="row"
              style={{
                fontWeight: 350,
                fontSize: "30px"
              }}
            >
              Collaborate on Data to build powerful AI models together
            </div>
            <div
              className="row"
              style={{ position: "absolute", top: "0px", right: "20px" }}
            >
              <span
                style={{
                  fontSize: "18px",
                  fontWeight: 350
                }}
              >
                Login As
              </span>
              <Link className="link-login" to="/Collaboratives">
                <DefaultButton
                  onClick={() => {
                    this.prepareURLS("810917c0-9083-4afa-b783-caa9010dc806");
                  }}
                >
                  Collaborative Admin
                </DefaultButton>
              </Link>
              <Link to="/Collaboratives" className="link-login">
                <DefaultButton
                  onClick={() => {
                    this.prepareURLS("5F304F82-1A81-459C-80B1-89D107FC9262");
                  }}
                >
                  Collaborator
                </DefaultButton>
              </Link>
            </div>
          </div>
        </div>
        <div className="half"> sdfa</div>
      </div>
    );
  }
}

export default Login;
