import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import {
  CommandBarButton,
  DefaultButton,
  PrimaryButton
} from "office-ui-fabric-react/lib/Button";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  Persona,
  PersonaSize
  // PersonaPresence
} from "office-ui-fabric-react/lib/Persona";
// import { List } from "office-ui-fabric-react/lib/List";
import { Link } from "react-router-dom";
import {
  DetailsList,
  DetailsRow,
  DetailsListLayoutMode,
  SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import { Label, Modal, Checkbox } from "office-ui-fabric-react";
// import { Callout } from "office-ui-fabric-react/lib/Callout";
// import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { mergeStyleSets } from "office-ui-fabric-react/lib/Styling";
import { InvContent } from "../components/Collabrative";
import {
  getInvitations,
  getInvitationInfo,
  joinMember
} from "../actions/collaborativeInviteAction";
import "./Invitations.scss";

const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: "16px"
  },
  fileIconCell: {
    textAlign: "center",
    selectors: {
      "&:before": {
        content: ".",
        display: "inline-block",
        verticalAlign: "middle",
        height: "100%",
        width: "0px",
        visibility: "hidden"
      }
    }
  },
  fileIconImg: {
    verticalAlign: "middle",
    maxHeight: "16px",
    maxWidth: "16px"
  },
  controlWrapper: {
    display: "flex",
    flexWrap: "wrap"
  },
  exampleToggle: {
    display: "inline-block",
    marginBottom: "10px",
    marginRight: "30px"
  },
  selectionDetails: {
    marginBottom: "20px"
  }
});
class Invitations extends Component {
  constructor(props) {
    super(props);
    const that = this;

    that.t2 = React.createRef();
    const columns = [
      {
        key: "column1",
        name: "File Type",
        className: classNames.fileIconCell,
        iconClassName: classNames.fileIconHeaderIcon,
        ariaLabel:
          "Column operations for File type, Press to sort on File type",
        iconName: "Page",
        isIconOnly: true,
        fieldName: "name",
        minWidth: 16,
        maxWidth: 16,
        onRender: item => (
          <div>
            <Icon
              style={{ fontSize: "16px" }}
              iconName="Mail"
              className="ms-IconExample"
            />
          </div>
        )
      },
      {
        key: "column2",
        name: "Name",
        fieldName: "name",
        minWidth: 210,
        maxWidth: 230,
        isRowHeader: true,
        isResizable: true,
        // isSorted: true,
        isSortedDescending: false,
        sortAscendingAriaLabel: "Sorted A to Z",
        sortDescendingAriaLabel: "Sorted Z to A",
        data: "string",
        isPadded: true,
        onRender: item => (
          <span fontSize="14px" color="#323130">
            {item.collaborationName}
          </span>
        )
      },
      {
        key: "column3",
        name: "Received On",
        fieldName: "dateModifiedValue",
        minWidth: 220,
        maxWidth: 280,
        isResizable: true,
        data: "number",
        onRender: item => (
          <span fontSize="12px" color="#797775">
            {moment(item.invitedAt).format("ddd DD-MMM-YYYY hh:mm A")}
          </span>
        ),
        isPadded: true
      },
      {
        key: "column4",
        name: "Sent By",
        fieldName: "modifiedBy",
        minWidth: 210,
        maxWidth: 250,
        isResizable: true,
        isCollapsible: true,
        data: "string",
        onRender: item => (
          <span color="#797775" fontSize="12px">
            {item.invitedBy.fullName}
          </span>
        ),
        isPadded: true
      },
      {
        key: "column5",
        name: "Status",
        fieldName: "fileSizeRaw",
        minWidth: 150,
        maxWidth: 190,
        isResizable: true,
        isCollapsible: true,
        data: "number",

        onRender: item => (
          <CommandBarButton
            // className="hardcode"
            iconProps={{ iconName: "" }}
            style={{
              background: "none",
              color: item.status !== "Accepted" ? "orange" : "#0078D4",
              fontSize: "12px"
            }}
            text={item.status}
          />
        )
      }
    ];
    this.state = {
      columns,
      items: []
    };
  }
  static getDerivedStateFromProps(nextProps) {
    return {
      items: nextProps.invitations,
      invitationInfo: nextProps.invitationInfo,
      termsOfUses: nextProps.termsOfUses
    };
  }
  componentDidMount() {
    this.props.getInvitations();
  }
  toggleDialog = collaborationId => {
    this.setState({
      isOpen: false
    });
  };
  onRenderRow = props => {
    const that = this;
    const { item } = props;
    return (
      <div className={item.status === "Accepted" ? "pointer" : ""}>
        <DetailsRow
          {...props}
          onClick={() => {
            // if (item.status === "Accepted") {
              that.setState(
                {
                  isOpen: true,
                  invitedAt: item.invitedAt
                },
                () => {
                  that.props.getInvitationInfo(item.collaborationId);
                }
              );
            // }
          }}
        />
      </div>
    );
  };
  render() {
    const {
      items = [],
      columns,
      isOpen,
      invitationInfo = {},
      invitedAt
    } = this.state;
    const { termsOfUses = [] } = invitationInfo;
    return (
      <Pivot className="invitations">
        <PivotItem
          itemKey="pivotItemKey_0"
          headerText="Received"
          style={{ height: "100%" }}
          itemCount={items.length}
        >
          <Modal
            isOpen={isOpen}
            isBlocking={false}
            containerClassName="container inv-modal"
          >
            <div className="header">
              <div className="col-xs-11 text-center">
                <b>Invitation</b>: {Object(invitationInfo.information).name}
              </div>
              <div
                className="col-xs-1 pull-right"
                style={{ textAlign: "right" }}
              >
                <Icon
                  iconName="Cancel"
                  className="ms-IconExample"
                  onClick={this.toggleDialog}
                />
              </div>
            </div>
            {Object.keys(invitationInfo).length ? (
              <InvContent
                invitationInfo={invitationInfo}
                invitedAt={invitedAt}
              />
            ) : null}
            <footer className="text-center">
              <Checkbox
                onRenderLabel={props => {
                  return (
                    <div>
                      I agree to <Link to="#test">{props.label}</Link>
                    </div>
                  );
                }}
                label={`${Object(termsOfUses[0]).policyName}, ${
                  Object(termsOfUses[1]).policyName
                }  ${
                  termsOfUses.length > 2
                    ? `and ${termsOfUses.length - 2} Other Documents`
                    : ""
                }`}
                onChange={(ev, isChecked) => {
                  this.setState({
                    isAgreed: isChecked
                  });
                }}
              />
              <div>
                <PrimaryButton
                  disabled={!this.state.isAgreed}
                  text="Join"
                  onClick={() => {
                    this.setState(
                      {
                        isOpen: false
                      },
                      () => {
                        this.props.joinMember(invitationInfo.collaborationId);
                      }
                    );
                  }}
                />
              </div>
            </footer>
          </Modal>
          <Label style={{ padding: "16px", fontSize: "24px" }}>
            Received Invitations
          </Label>
          <div className="row" style={{ margin: "0px", padding: "10px 30px" }}>
            <DetailsList
              selectionMode={SelectionMode.none}
              items={items}
              columns={columns}
              onRenderRow={this.onRenderRow}
            />
          </div>
        </PivotItem>
        <PivotItem
          itemKey="pivotItemKey_1"
          headerText="Sent"
          style={{ height: "100%" }}
        >
          <div className="sample">
            -----------------------In Progress------------------------
          </div>
        </PivotItem>
      </Pivot>
    );
  }
}

function mapStateToProps(state) {
  const { invitations, invitationInfo } = state.collaboratives;
  return {
    invitations,
    invitationInfo
  };
}

function mapDispatchToProps(dispatch) {
  return {
    getInvitations: () => dispatch(getInvitations()),
    getInvitationInfo: collaborationId =>
      dispatch(getInvitationInfo(collaborationId)),
    joinMember: collaborationId => dispatch(joinMember(collaborationId))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Invitations);
