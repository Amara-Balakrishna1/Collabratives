import React, { Component } from "react";
import './Activity.scss';

class Activity extends Component {
  render() {
    return <div className="detail-log">Activity</div>;
  }
}

export default Activity;
