const config = {
  "content-type": "application/json; charset=utf-8",
  "Cache-Control": "no-cache",
  type: "application/json"
};

export default config;
