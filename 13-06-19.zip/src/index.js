import React from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import { Provider } from "react-redux";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { initializeIcons } from "@uifabric/icons";
import { registerIcons } from "office-ui-fabric-react/lib/Styling";
import reducers from "./reducers";
// import Header from "./container/LayoutContainer";
// import Collaboratives from "./container/CollaborativesContainer";
// import Collaborative from "./container/CollaborativeContainer";
// import Activity from "./container/Activity";
import { Header, Collaborative, Collaboratives, Activity } from "./container";
import * as serviceWorker from "./serviceWorker";
import "office-ui-fabric-react/dist/css/fabric.min.css";
import "react-super-select/lib/react-super-select.css";
import "./index.scss";

initializeIcons(undefined, { disableWarnings: true });

registerIcons({
  icons: {
    "collabrative-svg": (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
      >
        <g clipPath="url(#clip0)">
          <path
            d="M14.9001 10.4L15.3001 10.8L15.7001 11.3C15.8117 11.4821 15.8801 11.6874 15.9001 11.9C15.9804 12.0893 16.0147 12.2949 16.0001 12.5C15.9812 12.8411 15.9139 13.1778 15.8001 13.5C15.6703 13.788 15.5021 14.0571 15.3001 14.3L14.5001 14.8L13.5001 15C13.0333 15.0226 12.5734 14.8811 12.2001 14.6C11.6105 15.0692 10.9292 15.4099 10.2001 15.6C9.50271 15.8854 8.75331 16.0216 8.0001 16C7.24755 16.0132 6.49983 15.8773 5.8001 15.6C5.07097 15.4099 4.3897 15.0692 3.8001 14.6C3.42681 14.8811 2.96686 15.0226 2.5001 15L1.5001 14.8L0.700101 14.3C0.498094 14.0571 0.3299 13.788 0.200101 13.5C0.0863197 13.1778 0.0189775 12.8411 0.000100956 12.5C-0.0144836 12.2949 0.0197878 12.0893 0.100101 11.9C0.120128 11.6874 0.18854 11.4821 0.300101 11.3L0.700101 10.8C0.800101 10.6 1.0001 10.5 1.1001 10.4C1.1162 10.1622 1.08213 9.92375 1.0001 9.7V9C1.00144 8.28942 1.10242 7.58253 1.3001 6.9C1.49665 6.22265 1.80051 5.58118 2.2001 5L3.7001 3.5C4.22745 3.05002 4.83944 2.71002 5.5001 2.5C5.50921 2.1577 5.57685 1.81948 5.7001 1.5C5.80696 1.20032 5.97755 0.927374 6.2001 0.7L7.0001 0.2L8.0001 0L9.0001 0.2L9.8001 0.7C10.0227 0.927374 10.1932 1.20032 10.3001 1.5C10.4234 1.81948 10.491 2.1577 10.5001 2.5C11.1608 2.71002 11.7728 3.05002 12.3001 3.5L13.8001 5C14.1997 5.58118 14.5035 6.22265 14.7001 6.9C14.8978 7.58253 14.9988 8.28942 15.0001 9V9.7C14.9181 9.92375 14.884 10.1622 14.9001 10.4ZM1.0001 12.5C0.985516 12.7051 1.01979 12.9107 1.1001 13.1L1.4001 13.6L1.9001 13.9H3.1001L3.6001 13.6L3.9001 13.1C3.98041 12.9107 4.01469 12.7051 4.0001 12.5C4.01469 12.2949 3.98041 12.0893 3.9001 11.9L3.6001 11.4L3.1001 11.1H1.9001L1.4001 11.4L1.1001 11.9C1.01979 12.0893 0.985516 12.2949 1.0001 12.5ZM8.0001 15C8.61232 14.9973 9.22011 14.896 9.8001 14.7C10.3789 14.5359 10.9216 14.2646 11.4001 13.9L11.1001 13.2C11.0115 12.978 10.9772 12.738 11.0001 12.5C11.019 12.1589 11.0863 11.8222 11.2001 11.5C11.3299 11.212 11.4981 10.9429 11.7001 10.7L12.5001 10.2L13.5001 10H13.9001C13.9828 9.67346 14.0165 9.33645 14.0001 9C13.9974 8.38778 13.8961 7.77999 13.7001 7.2C13.5712 6.65761 13.333 6.14721 13.0001 5.7C12.6823 5.19745 12.2757 4.75693 11.8001 4.4C11.3769 3.98743 10.8633 3.67927 10.3001 3.5L9.9001 4.1C9.8001 4.3 9.6001 4.4 9.4001 4.6L8.7001 4.9H7.3001L6.6001 4.6L6.1001 4.1L5.7001 3.5C5.13691 3.67927 4.62331 3.98743 4.2001 4.4C3.72454 4.75693 3.31791 5.19745 3.0001 5.7C2.68664 6.15855 2.45019 6.66522 2.3001 7.2C2.10408 7.77999 2.00278 8.38778 2.0001 9C1.98371 9.33645 2.01742 9.67346 2.1001 10H3.2001L4.1001 10.5C4.38414 10.7176 4.62209 10.9896 4.8001 11.3C4.9233 11.6885 4.99064 12.0925 5.0001 12.5C5.02303 12.738 4.98874 12.978 4.9001 13.2L4.6001 13.9C5.07859 14.2646 5.62135 14.5359 6.2001 14.7C6.7801 14.896 7.38788 14.9973 8.0001 15ZM8.0001 1H7.4001L6.9001 1.3L6.6001 1.8C6.51979 1.98928 6.48552 2.19491 6.5001 2.4C6.48552 2.60509 6.51979 2.81072 6.6001 3L6.9001 3.5L7.4001 3.8H8.6001L9.1001 3.5L9.4001 3C9.48041 2.81072 9.51469 2.60509 9.5001 2.4C9.51469 2.19491 9.48041 1.98928 9.4001 1.8L9.1001 1.3L8.6001 1H8.0001ZM13.5001 14H14.1001L14.6001 13.7L14.9001 13.2C14.9804 13.0107 15.0147 12.8051 15.0001 12.6C15.0147 12.3949 14.9804 12.1893 14.9001 12L14.6001 11.5L14.1001 11.2H12.9001L12.4001 11.5L12.1001 12C12.0198 12.1893 11.9855 12.3949 12.0001 12.6C11.9855 12.8051 12.0198 13.0107 12.1001 13.2L12.4001 13.7L12.9001 14H13.5001Z"
            fill="black"
          />
        </g>
        <defs>
          <clipPath id="clip0">
            <rect width="16" height="16" fill="white" />
          </clipPath>
        </defs>
      </svg>
    )
  }
});

const Root = ({ store }) => (
  <Provider store={store}>
    <Router>
      <Header className="app-header" />
      <main className="main">
        <Switch>
          <Route exact path="/" component={Collaboratives} />
          <Route exact path="/collaborative/:collaborationId" component={Collaborative} />
          <Route exact path="/activityLog" component={Activity} />
        </Switch>
      </main>
    </Router>
  </Provider>
);

const middleware = [thunk];

const createStoreWithMiddleware = applyMiddleware(...middleware)(createStore);
const store = createStoreWithMiddleware(reducers);

Root.propTypes = {
  store: PropTypes.object.isRequired
};

// export default Root

ReactDOM.render(<Root store={store} />, document.getElementById("root"));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
