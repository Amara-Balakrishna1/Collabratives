import React, { Component } from "react";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import {
  CommandBarButton,
  DefaultButton
} from "office-ui-fabric-react/lib/Button";
import { Dropdown } from "office-ui-fabric-react/lib/Dropdown";
// import ReactSuperSelect from "react-super-select";
// import DummyImg from "../../images/Dummy_flag.png";
import Fileinput from "./Fileinput";
import "./modalStyle.scss";
// import { validate } from "@babel/types";

class AddCollab extends Component {
  state = {
    formFields: {
      imageUrl: ''
    },
    tcArray: [
      {
        documentName: "Terms and Conditions"
      },
      {
        documentName: "Privacy Policy"
      }
    ],
    newFields: []
  };
  onRenderDescription = props => (
    <Stack horizontal verticalAlign="center">
      <span className={props.required ? "req" : ""}>{props.label}</span>
      <Icon iconName="Info" title="Info" ariaLabel="Info" />
    </Stack>
  );
  setActiveTab = index => {
    this.setState({
      selectedPivotKey: "pivotItemKey_" + index
    });
  };
  onChange = (field, value) => {
    const { formFields } = this.state;
    formFields[field] = value;
    this.setState({
      formFields
    });
  };
  fileChange = (root, index, data) => {
    const subData = this.state[root];
    subData[index].documentUrl = data;
    this.setState({
      [root]: subData
    });
  };
  setTCName = (index, data) => {
    const subData = this.state.newFields;
    subData[index].documentName = data;
    this.setState({
      newFields: subData
    });
  };
  validateFields = () => {
    const reqFields = [
      'name',
      'goal',
      'industries',
      'dataContext',
      'storageLocation',
      'recommendedFormats'
    ];
    const { formFields } = this.state;
    return reqFields.filter(d => formFields[d]).length !== reqFields.length;
  }
  render() {
    const {
      showDialog,
      toggleDialog,
      industriesd = [],
      formats = []
    } = this.props;
    const {
      formFields: {
        name,
        goal,
        industries = [],
        dataContext,
        storageLocation,
        subscriptionId,
        resourceGroupName,
        recommendedFormats = []
        // imageUrl
      },
      tcArray,
      newFields,
      // filename,
      selectedPivotKey
    } = this.state;
    return (
      <Modal
        isOpen
        className={showDialog ? '': 'hide'}
        isBlocking={false}
        containerClassName="container"
      >
        <div className="header">
          <div className="col-xs-11">Create Collaborative</div>
          <div className="col-xs-1 pull-right" style={{ textAlign: "right" }}>
            <Icon
              iconName="Cancel"
              className="ms-IconExample"
              onClick={toggleDialog}
            />
          </div>
        </div>
        <div className="row" style={{ height: "90%" }}>
          <Pivot className="tabHeader" selectedKey={selectedPivotKey}>
            <PivotItem
              onLinkClick={() => this.setActiveTab(0)}
              itemKey="pivotItemKey_0"
              headerText="Collaborative Details"
              style={{ height: "100%" }}
            >
              <div className="row" style={{ height: "90%" }}>
                <div className="col-xs-12">
                  The information will send to Collaborators you invite
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Collaborative Name"
                    value={name}
                    onChange={(ev, value) => this.onChange("name", value)}
                    required
                    placeholder="Ex. Cardiac Collaborative"
                    className="collab-field"
                    onRenderLabel={this.onRenderDescription}
                  />
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="req">Select Industry</span>
                        <Icon iconName="Info" title="Info" ariaLabel="Info" />
                      </Stack>
                      <Dropdown
                        // label="Select Industry"
                        selectedKey={industries}
                        multiSelect
                        placeholder="Select Industry"
                        onChange={(ev, value) => {
                          if (value.selected) {
                            industries.push(value.key);
                          } else {
                            industries.splice(
                              industries.indexOf(value.key),
                              1
                            );
                          }
                          this.onChange("industries", industries);
                        }}
                        // onRenderTitle={this.onRenderDescription}
                        options={
                          industriesd.map(d => ({
                            key: d,
                            text: d
                          }))
                          //   [
                          //   { value: "banana", name: "Banana" },
                          //   { value: "orange", name: "Orange" },
                          //   { value: "grape", name: "Grape" }
                          // ]
                        }
                      />
                    </div>
                  </div>
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Goal"
                    value={goal}
                    onChange={(ev, value) => {
                      this.onChange("goal", value);
                    }}
                    required
                    placeholder="Why does this collaborative exist? What is end goal?"
                    className="collab"
                    onRenderLabel={this.onRenderDescription}
                    multiline
                  />
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Data context"
                    value={dataContext}
                    onChange={(ev, value) => {
                      this.onChange("dataContext", value);
                    }}
                    required
                    placeholder="Ex. health records of children 18-24 with cardiac event"
                    className="collab-field"
                    onRenderLabel={this.onRenderDescription}
                  />
                </div>
                <div className="col-xs-12">
                  {/* <TextField
                  label="Collaborative Image"
                  value={context}
                  onChange={this.onChange}
                  // required
                  placeholder="Ex. Image URL"
                  className="collab-field"
                  onRenderLabel={this.onRenderDescription}
                /> */}
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <div className="ms-Stack">Collaborative Image</div>
                      <div
                        className="ms-TextField-fieldGroup"
                        style={{ border: "none" }}
                      >
                        <Fileinput
                          typeImg
                          fileChange={this.onChange}
                          id="image"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Subscription Id"
                    value={subscriptionId}
                    onChange={(ev, value) => {
                      this.onChange("subscriptionId", value);
                    }}
                    placeholder="Ex. b2251f1c-ceaa-4ea2-bdfb-7adec3f037de"
                    className="collab-field"
                    onRenderLabel={this.onRenderDescription}
                  />
                </div>
                <div className="col-xs-12">
                  <TextField
                    label="Resource Group Name"
                    value={resourceGroupName}
                    onChange={(ev, value) => {
                      this.onChange("resourceGroupName", value);
                    }}
                    placeholder="Ex. collaboratives-dev-test01"
                    className="collab-field"
                    onRenderLabel={this.onRenderDescription}
                  />
                </div>

                <div className="col-xs-12">
                  <TextField
                    label="Default Storage Location"
                    value={storageLocation}
                    onChange={(ev, value) => {
                      this.onChange("storageLocation", value);
                    }}
                    required
                    placeholder="Ex. Azure Location"
                    className="collab-field"
                    onRenderLabel={this.onRenderDescription}
                  />
                </div>
                <div className="col-xs-12">
                  <div className="collab-field">
                    <div className="ms-TextField-wrapper">
                      <Stack horizontal verticalAlign="center">
                        <span className="req">Recommended Format</span>
                        <Icon iconName="Info" title="Info" ariaLabel="Info" />
                      </Stack>
                      <Dropdown
                        selectedKeys={recommendedFormats}
                        placeholder="Select Recommended Format"
                        // label={() => (
                        //   <Stack horizontal verticalAlign="center">
                        //     <span className="req">Recommended Format</span>
                        //     <Icon iconName="Info" title="Info" ariaLabel="Info" />
                        //   </Stack>
                        // )} //"Recommended Format"
                        onChange={(ev, value) => {
                          if (value.selected) {
                            recommendedFormats.push(value.key);
                          } else {
                            recommendedFormats.splice(
                              recommendedFormats.indexOf(value.key),
                              1
                            );
                          }
                          // const arr = [value.key];
                          this.onChange(
                            "recommendedFormats",
                            recommendedFormats
                          );
                        }}
                        multiSelect
                        options={formats.map(d => ({
                          key: d,
                          text: d
                        }))}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xs-12">
                <PrimaryButton
                  text="Continue"
                  disabled={this.validateFields()}
                  onClick={() => this.setActiveTab(1)}
                />
              </div>
            </PivotItem>
            <PivotItem
              itemKey="pivotItemKey_1"
              headerText="Terms of Use"
              style={{ height: "100%" }}
              className="TC"
            >
              <div
                className="table"
                style={{ height: "90%", overflow: "auto" }}
              >
                <div className="row">
                  Upload Legal documents you would like all collaborators to
                  accept or adhere by
                </div>
                {tcArray.map((d, i) => (
                  <div className="row">
                    <div className="collab-field">
                      <div className="ms-TextField-wrapper">
                        {/* <div className="ms-Stack">{d.name}</div> */}

                        <Stack horizontal verticalAlign="center">
                          <span>{d.documentName}</span>
                          <Icon iconName="Info" title="Info" ariaLabel="Info" />
                        </Stack>
                        <div
                          className="ms-TextField-fieldGroup"
                          style={{ border: "none" }}
                        >
                          <Fileinput
                            root="tcArray"
                            label={d.documentName}
                            id={`tc-${i}`}
                            index={i}
                            fileChange={this.fileChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {newFields.length ? (
                  <div className="newFields">
                    {newFields.map((d, i) => (
                      <div className="row moreField">
                        <div className="collab-field">
                          <TextField
                            value={d.documentName}
                            onChange={(ev, value) => {
                              this.setTCName(i, value);
                            }}
                            // required
                            placeholder="Ex. Label"
                          />
                          <Fileinput
                            root="newFields"
                            label={d.documentName}
                            // url={d.documentUrl}
                            id={`nf-${i}`}
                            index={i}
                            fileChange={this.fileChange}
                          />
                          <DefaultButton
                            className="pull-right removeButton"
                            // iconProps={{ iconName: "Add" }}
                            style={{ background: "none", color: "#0078D4" }}
                            onClick={() => {
                              newFields.splice(i, 1);
                              this.setState({
                                newFields
                              });
                            }}
                            text="remove"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : null}
                <div className="col-xs-12" style={{ padding: "20px 10px" }}>
                  <CommandBarButton
                    iconProps={{ iconName: "Add" }}
                    style={{ background: "none", color: "#0078D4" }}
                    onClick={() => {
                      newFields.push({});
                      this.setState({
                        newFields
                      });
                    }}
                    text="Add More"
                  />
                </div>
              </div>
              <div className="col-xs-12">
                <PrimaryButton
                  text="Continue"
                  disabled={this.validateFields()}
                  onClick={() => {
                    const {
                      formFields = {},
                      newFields = [],
                      tcArray = []
                    } = this.state;
                    const data = {
                      ...formFields,
                      termsOfUses: [...newFields, ...tcArray].filter(d => d.documentUrl),
                      industries: formFields.industries,
                      defaultStorageAccountId: formFields.storageLocation
                    };
                    this.props.createCollaborative(data);
                    this.props.toggleDialog(false);
                  }}
                />
              </div>
            </PivotItem>
          </Pivot>
        </div>
      </Modal>
    );
  }
}

export default AddCollab;
