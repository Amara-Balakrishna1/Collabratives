/* global $ */

import React, { Component } from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
// import DummyImg from "../../images/Dummy_flag.png";
import axios from "axios";
// import config from "../../actions/config";
import urls from "../../actions/actionURLS";

class Fileinput extends Component {
  constructor(props) {
    super(props);
    this[props.id] = React.createRef();
    this.state = {
      fileName: ""
    };
  }
  componentDidMount() {
    const that = this;
    const { id } = that.props;
    $(this[id].current).on("change.bs.fileinput", function(e) {
      const { label, index, root } = that.props;
      const fileContent = e.target.files[0];
      const { name = "" } = fileContent || {};
      var formData = new FormData();
      formData.append(label || "image", fileContent);
      // ----------------------------
      that.setState({
        fileName: name
      });
      // ------------------------
      if (fileContent) {
        axios
          .post(urls.fileUpload, formData, {
            headers: {
              "Content-Type": "multipart/form-data"
            }
          })
          .then(result => {
            // console.log(result, "asdf");
            if (that.props.typeImg) {
              that.props.fileChange("imageUrl", result.data.image);
            } else {
              that.props.fileChange(root, index, result.data[label]);
            }
          });
      } else {
        if (that.props.typeImg) {
          that.props.fileChange("image", "");
        } else {
          that.props.fileChange(root, index, "");
        }
      }
    });
  }
  render() {
    const { fileName } = this.state;
    const { typeImg, id, root } = this.props;
    return (
      <div style={{ display: "inline-block" }}>
        {typeImg ? (
          <div className="file-upload imgU">
            <div
              className="fileinput fileinput-new"
              data-provides="fileinput"
              style={{ width: "400px", height: "40px" }}
            >
              {/* <div
                className="fileinput-exists"
                style={{ width: "10%", height: "100%" }}
              >
                <img src={DummyImg} alt="..." />
              </div> */}
              <div
                className="fileinput-preview fileinput-exists thumbnail"
                style={{ maxWidth: "200px", maxHeight: "150px" }}
              />
              <div style={{ display: "inline-block" }}>
                <span className="btn btn-default btn-file">
                  <span className="fileinput-new">Upload Image</span>
                  <span className="fileinput-exists">{fileName}</span>
                  {/* <span className="fileinput-exists">change</span> */}
                  <input
                    ref={this[id]}
                    type="file"
                    accept="image/*"
                    name="..."
                    id="file1"
                    onChange={event => {
                      console.log("asadf");
                      this.setState({
                        fileName: event.target.files[0].name
                      });
                    }}
                  />
                </span>
                <a
                  href="javascript:void(0)"
                  className="btn btn-default fileinput-exists"
                  data-dismiss="fileinput"
                >
                  <Icon iconName="Cancel" className="ms-IconExample" />
                </a>
              </div>
            </div>
          </div>
        ) : (
          <div
            className="fileinput fileinput-new input-group"
            data-provides="fileinput"
          >
            <div
              className="fileinput-exists form-control"
              data-trigger="fileinput"
            >
              <span className="fileinput-filename" />
            </div>
            <span className="input-group-append">
              <span
                className="btn btn-default btn-file input-group-text fileinput-exists"
                data-dismiss="fileinput"
              >
                Remove
              </span>

              <span className="btn btn-default btn-file input-group-text btn-file">
                <span className="fileinput-new">
                  Upload {root !== "newFields" ? "" : "Document"}
                </span>
                <span className="fileinput-exists">Change</span>
                <input ref={this[id]} type="file" name="..." accept="application/msword, application/pdf" />
              </span>
            </span>
          </div>
        )}
      </div>
    );
  }
}

export default Fileinput;
