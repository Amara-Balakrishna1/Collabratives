import React, { Component } from "react";
import { Label } from "office-ui-fabric-react/lib/Label";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton } from "office-ui-fabric-react";
import Wrapper from "./Addwrapper";

class AddMember extends Component {
  // constructor(props) {}
  render() {
    const { toggleData, subscription = "" } = this.props;
    return (
      <Wrapper toggleData={toggleData} name="showAMember">
        <div
          className="row"
          style={{ height: "40%", padding: "20px", margin: "0px" }}
        >
          <Label>Invite Organization</Label>
          <TextField
            label="Member Name"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
          <TextField
            label="Email"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
          <TextField
            label="Organization"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
          <TextField
            label="Role"
            value={subscription}
            onChange={(ev, value) => this.onChange("subscription", value)}
            placeholder="Ex. John"
            className="collab-field"
            styles={{ padding: "5px" }}
          />
        </div>

        <div className="row" style={{ padding: "20px", margin: "0px" }}>
          <PrimaryButton text="Invite" />
        </div>
        <hr />
        <div
          className="row"
          style={{ height: "40%", padding: "20px", margin: "0px" }}
        >
          <span>sadfasd</span>
        </div>
      </Wrapper>
    );
  }
}

export default AddMember;
