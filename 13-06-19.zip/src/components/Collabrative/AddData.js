import React, { Component } from "react";
import {
  Pivot,
  PivotItem,
  // PivotLinkFormat,
  PivotLinkSize
} from "office-ui-fabric-react/lib/Pivot";
import { Toggle } from "office-ui-fabric-react/lib/Toggle";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Label } from "office-ui-fabric-react/lib/Label";
import { Callout, DirectionalHint } from "office-ui-fabric-react/lib/Callout";
import { Calendar, DayOfWeek } from "office-ui-fabric-react/lib/Calendar";
import { FocusTrapZone } from "office-ui-fabric-react/lib/FocusTrapZone";
import {
  CommandBarButton,
  // DefaultButton,
  PrimaryButton
} from "office-ui-fabric-react/lib/Button";
import moment from "moment";
import Wrapper from "./Addwrapper";
import "./addData.scss";

const DayPickerStrings = {
  months: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ],
  shortMonths: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  days: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ],
  shortDays: ["S", "M", "T", "W", "T", "F", "S"],
  goToToday: "Go to today",
  weekNumberFormatString: "Week number {0}",
  prevMonthAriaLabel: "Previous month",
  nextMonthAriaLabel: "Next month",
  prevYearAriaLabel: "Previous year",
  nextYearAriaLabel: "Next year",
  prevYearRangeAriaLabel: "Previous year range",
  nextYearRangeAriaLabel: "Next year range",
  closeButtonAriaLabel: "Close"
};
class AddCollab extends Component {
  constructor(props) {
    super(props);
    var someDate = new Date();
    var numberOfDaysToAdd = 6;
    someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
    this.state = {
      formFields: {
        name: "",
        c1value: new Date(),
        c2value: someDate
      },
      fields: []
    };
    this.Calendar1 = React.createRef();
    this.Calendar2 = React.createRef();
  }
  onChange = (field, value) => {
    const { formFields } = this.state;
    formFields[field] = value;
    this.setState({
      formFields
    });
  };
  toggleCallout(calander) {
    this.setState({
      [calander]: !this.state[calander]
    });
  }
  onSelectDate(cfield, date, calander) {
    const { formFields } = this.state;
    formFields[cfield] = date;
    this.setState(
      {
        formFields
      },
      () => {
        this.toggleCallout(calander);
      }
    );
  }
  render() {
    const {
      calander1,
      calander2,
      formFields = {},
      fields = [],
      activeTab
    } = this.state;
    const {
      name,
      c2value,
      c1value,
      subscription,
      resourceGroup,
      description,
      toggle
    } = formFields;
    const { toggleData } = this.props;
    return (
      <Wrapper toggleData={toggleData} name="showAddData">
        <Pivot
          className="tabHeader"
          // linkFormat={PivotLinkFormat.tabs}
          linkSize={PivotLinkSize.large}
          selectedKey={activeTab}
        >
          <PivotItem
            itemKey="Tab1"
            className="tabContent"
            itemIcon={activeTab ? "StatusCircleCheckmark" : ""}
            headerText="Select Data"
          >
            <div style={{ height: "100%" }} className="col-xs-12">
              <TextField
                label="Subscription"
                value={subscription}
                onChange={(ev, value) => this.onChange("subscription", value)}
                placeholder="Ex. John"
                className="collab-field"
                styles={{ padding: "5px" }}
              />
              <TextField
                label="Resource Group"
                value={resourceGroup}
                onChange={(ev, value) => this.onChange("resourceGroup", value)}
                placeholder="Ex. John"
                className="collab-field"
                styles={{ padding: "5px" }}
              />
              <CommandBarButton
                iconProps={{ iconName: "Add" }}
                onClick={() => {
                  const { fields } = this.state;
                  fields.push("");
                  this.setState({
                    fields
                  });
                }}
                style={{ padding: "8px 4px", margin: "10px 0px" }}
                text="Add Fields"
              />
              {fields.map((d, i) => (
                <TextField
                  label=" "
                  value={d}
                  onChange={(ev, value) => {
                    const { fields } = this.state;
                    fields[i] = value;
                    this.setState({
                      fields
                    });
                  }}
                  placeholder="Ex. John"
                  className="collab-field"
                  styles={{ padding: "5px" }}
                />
              ))}
            </div>

            <PrimaryButton
              className="pull-right"
              text="Add"
              onClick={() => {
                this.setState({
                  activeTab: "Tab2"
                });
              }}
            />
          </PivotItem>
          <PivotItem
            className="tabContent"
            headerText="Description"
            itemKey="Tab2"
          >
            <div style={{ height: "100%" }}>
              <TextField
                label="Name the data set"
                value={name}
                onChange={(ev, value) => this.onChange("name", value)}
                placeholder="Ex. John"
                className="collab-field"
                style={{ padding: "15px 0px" }}
              />
              <Label className="comm-margin">Describe the data set</Label>
              <label className="ms-Label">
                Time Frame <span>(Optional)</span>
              </label>
              <div className="col-xs-12 comm-margin" style={{ padding: "0px" }}>
                <div
                  ref={this.Calendar1}
                  onClick={() => {
                    this.toggleCallout("calander1");
                  }}
                  className="col-xs-6"
                  style={{ padding: "0px" }}
                >
                  <div class="input-group">
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Username"
                      value={moment(c1value).format("DD-MMM-YYYY")}
                      onChange={() => {}}
                    />
                    <span className="icon-pos">
                      <Icon
                        style={{ fontSize: "16px" }}
                        iconName="Calendar"
                        className="ms-IconExample"
                      />
                    </span>
                  </div>
                </div>
                <div
                  onClick={() => {
                    this.toggleCallout("calander2");
                  }}
                  ref={this.Calendar2}
                  className="col-xs-6"
                  style={{ padding: "0px" }}
                >
                  <div class="input-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Username"
                      onChange={() => {}}
                      value={moment(c2value).format("DD-MMM-YYYY")}
                    />
                    <span className="icon-pos">
                      <Icon
                        style={{ fontSize: "16px" }}
                        iconName="Calendar"
                        className="ms-IconExample"
                      />
                    </span>
                  </div>
                </div>
              </div>
              {calander1 && (
                <Callout
                  isBeakVisible={false}
                  className="ms-DatePicker-callout"
                  gapSpace={0}
                  doNotLayer={false}
                  target={this.Calendar1.current}
                  directionalHint={DirectionalHint.bottomLeftEdge}
                  onDismiss={this._onDismiss}
                  setInitialFocus={true}
                >
                  <FocusTrapZone isClickableOutsideFocusTrap={true}>
                    <Calendar
                      onSelectDate={date => {
                        this.onSelectDate("c1value", date, "calander1");
                      }}
                      isMonthPickerVisible
                      value={c1value}
                      firstDayOfWeek={DayOfWeek.Sunday}
                      strings={DayPickerStrings}
                      isDayPickerVisible
                      highlightCurrentMonth
                      highlightSelectedMonth
                      showMonthPickerAsOverlay
                      showGoToToday
                    />
                  </FocusTrapZone>
                </Callout>
              )}
              {calander2 && (
                <Callout
                  isBeakVisible={false}
                  className="ms-DatePicker-callout"
                  gapSpace={0}
                  doNotLayer={false}
                  target={this.Calendar2.current}
                  directionalHint={DirectionalHint.bottomLeftEdge}
                  onDismiss={this._onDismiss}
                  setInitialFocus={true}
                >
                  <FocusTrapZone isClickableOutsideFocusTrap={true}>
                    <Calendar
                      onSelectDate={date => {
                        this.onSelectDate("c2value", date, "calander2");
                      }}
                      isMonthPickerVisible
                      value={c2value}
                      firstDayOfWeek={DayOfWeek.Sunday}
                      strings={DayPickerStrings}
                      isDayPickerVisible
                      highlightCurrentMonth
                      highlightSelectedMonth
                      showMonthPickerAsOverlay
                      showGoToToday
                    />
                  </FocusTrapZone>
                </Callout>
              )}
              <TextField
                label="Description"
                multiline
                rows={3}
                value={description}
                onChange={(ev, value) => this.onChange("description", value)}
                placeholder="Briefly describe the data set"
              />
              <Toggle
                defaultChecked
                className="comm-margin"
                onChange={(ev, checked) => this.onChange("toggle", checked)}
                inlineLabel
                label="Auto Sync"
                checked={toggle}
              />
            </div>
            <PrimaryButton
              className="pull-right"
              text="Save"
              onClick={() => console.log(this.state)}
            />
          </PivotItem>
        </Pivot>
      </Wrapper>
    );
  }
}
export default AddCollab;
