import Header from "./LayoutContainer";
import Collaboratives from "./CollaborativesContainer";
import Collaborative from "./CollaborativeContainer";
import Activity from "./Activity";

export { Header, Collaborative, Collaboratives, Activity };
